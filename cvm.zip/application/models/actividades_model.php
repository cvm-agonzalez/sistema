<?
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 
 */
class Actividades_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database('default');
    }
    
    public function reg_profesor($datos){
        $this->db->insert('profesores', $datos);
        return $this->db->insert_id();   
    }
    public function update_profesor($datos,$id){
        $this->db->where("Id",$id);
        $this->db->update('profesores', $datos);
        return true;   
    }    
    public function get_profesores(){
    	$this->db->order_by("apellido", "asc"); 
        $query = $this->db->get_where("profesores",array('estado' => '1'));
        return $query->result();
    }    
    public function get_profesor($id){
        $this->db->where("Id", $id); 
        $query = $this->db->get("profesores");
        if($query->num_rows() == '0'){
            return false;
        }else{        
            return $query->row();
        }
    }
    public function del_profesor($id){
        $this->db->where("Id", $id); 
        $query = $this->db->update("profesores",array("estado"=>'0'));
        return true;
    } 

    public function reg_lugar($datos){
        $this->db->insert('lugares', $datos);
        return $this->db->insert_id();   
    }
    public function update_lugar($datos,$id){
        $this->db->where("Id",$id);
        $this->db->update('lugares', $datos);
        return true;   
    }    
    public function get_lugares(){
        $this->db->order_by("nombre", "asc"); 
        $query = $this->db->get_where("lugares",array("estado"=>'1'));
        return $query->result();
    }    
    public function get_lugar($id){
        $this->db->where("Id", $id); 
        $query = $this->db->get("lugares");
        if($query->num_rows() == '0'){
            return false;
        }else{        
            return $query->row();
        }
    }
    public function del_lugar($id){
        $this->db->where("Id", $id); 
        $query = $this->db->update("lugares",array("estado"=>'0'));
        return true;
    } 

    public function reg_actividad($datos){
        $this->db->insert('actividades', $datos);
        return $this->db->insert_id();   
    }
    public function update_actividad($datos,$id){
        $this->db->where("Id",$id);
        $this->db->update('actividades', $datos);
        return true;   
    }    
    public function get_actividades(){
        $this->db->order_by("nombre", "asc"); 
        $query = $this->db->get_where("actividades",array("estado"=>'1'));
        return $query->result();
    }    
    public function get_actividad($id){
        $this->db->where("Id", $id); 
        $query = $this->db->get("actividades");
        return $query->row();
    }
    public function del_actividad($id){
        $this->db->where("Id", $id); 
        $query = $this->db->update("actividades", array("estado"=>'0'));
        return true;
    }
    public function get_act_asoc($sid){
        $this->db->order_by("estado", "desc");
        $this->db->where("sid", $sid);
        $query = $this->db->get("actividades_asociadas");
        if ($query->num_rows() == 0){
            $act_asoc = new stdClass();
            return $act_asoc;
        }else{
            foreach ($query->result() as $asoc) {
                $actividad = $this->get_actividad($asoc->aid);
                $actividad->estado = $asoc->estado;
                $actividad->asoc_id = $asoc->Id;
                if($actividad->estado == '1'){
                    $actividad->alta = $this->show_date($asoc->date);
                }else{
                    $actividad->alta = $this->show_date($asoc->date_alta);
                    $actividad->baja = $this->show_date($asoc->date);
                }
                $actividad->descuento = $asoc->descuento;
                $act_asoc[] = $actividad;
            }            
            return $act_asoc;
        } 
    }
    public function act_baja($sid,$aid){
        
        $this->db->where("Id", $aid);
        $query = $this->db->get('actividades_asociadas');
        $fecha = $query->row();
        $fecha = $fecha->date;

        $this->db->where("sid", $sid);
        $this->db->where("Id", $aid);
        $query = $this->db->update("actividades_asociadas",array('estado'=>'0','date_alta'=>$fecha));
        $alta = $this->show_date($fecha);
        $fecha = array();
        $fecha['alta'] = $alta;
        $fecha['baja'] = date('d/m/Y');
        $fecha['asoc_id'] = $aid;
        $fecha = json_encode($fecha);
        return $fecha;
    }
    public function act_alta($data){        
        $query = $this->db->insert("actividades_asociadas",$data);
        $iid = $this->db->insert_id(); 
        $actividad = $this->get_actividad($data['aid']);
        $actividad->asoc_id = $iid;
        $actividad->alta = date("d/m/Y");
        $actividad = json_encode($actividad);
        return $actividad;
    } 
    public function show_date($fecha){
        $fecha = explode('-', $fecha);
        $fecha2 = explode(' ', $fecha[2]);
        return $fecha2[0].'/'.$fecha[1].'/'.$fecha[0];
    }

    public function get_socios_actividad($id){
        $this->load->model('socios_model');
        $this->db->where('aid',$id);
        $this->db->where('estado',1);
        $query = $this->db->get('actividades_asociadas');
        $socios = $query->result();
        foreach ($socios as $socio) {
            $socio->info = $this->socios_model->get_socio($socio->sid);
        }
        return $socios;
    } 

    public function becar($id='',$beca)
    {    
        $this->db->where('Id',$id);
        $this->db->update('actividades_asociadas',array("descuento"=>$beca));
    }
}
?>