<?
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 
 */
class Pagos_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database('default');
    }
    
    public function get_cupon($sid){
        $this->load->model("socios_model"); 
        $socio = $this->socios_model->get_socio($sid);
        if($socio->tutor != 0){
            $grupo_familiar = true;
            //si el socio pertenece a un grupo familiar buscamos el cupon del tutor            
            return $this->get_cupon($socio->tutor);
        }

        $query = $this->db->get_where('cupones',array('sid'=>$sid,'estado'=>'1'));
        if($query->num_rows() == 0){
            $cupon = new stdClass();
            $cupon->monto = '0';
            return $cupon;
        }else{
            return $query->row();
        }
    }

    public function get_cupon_by_id($id='')
    {
        $this->db->where('Id',$id);
        $query = $this->db->get('cupones');
        if($query->num_rows() == 0){return false;}
        $cupon = $query->row();
        $query->free_result();
        return $cupon;
    }

    public function get_monto_socio($sid){ // devuelve el importe que deberá pagar un socio o su tutor, en caso de pertenecer a un grupo familiar        
        $grupo_familiar = $tutor = false;
        $monto = 0;
        //obtenemos el precio de cada categoria
        $this->load->model("general_model");
        $cats = $this->general_model->get_cats();

        $precio_excedente = $cats['3']->precio_unit;

        //buscamos si el socio pertenece a un grupo familiar
        $this->load->model("socios_model"); 
        $socio = $this->socios_model->get_socio($sid);

        if($socio->tutor != 0){
            $grupo_familiar = true;
            //si el usuario pertenece a un grupo familiar buscamos el monto del tutor            
            return $this->get_monto_socio($socio->tutor);
        }   

        //buscamos si el usuario es tutor de grupo familiar
        $query = $this->db->get_where('socios',array('tutor'=>$sid,'estado'=>'1'));
        if($query->num_rows() != 0){
            $tutor = true;
            $familiares_a_cargo = $query->result();  
            $fam_actividades = array();
            $total_familiares = (count($familiares_a_cargo) + 1);  //la cantidad de familiares a cargo mas el tutor
            $familiares = array();
            foreach ($familiares_a_cargo as $familiar) { // buscamos las actividades de cada familiar
                $fam_actividades = $this->get_actividades_socio($familiar->Id);
                $familiares[] = array('datos' => $familiar, 'actividades' => $fam_actividades);
            }

            //buscamos las actividades del socio titular
            $socio_actividades =  $this->get_actividades_socio($sid);
            //buscamos los familiares excedentes
            $excedente = $total_familiares - 4; // 4 = total del grupo familiar
            $monto_excedente = 0;
            for ($i=0; $i < $excedente; $i++) { 
                $monto_excedente = $monto_excedente + $precio_excedente;
            }
                    
            $monto = $cats['3']->precio - ($cats['3']->precio * $socio->descuento / 100); //valor de la cuota de grupo familiar
            $total = $monto + ( $monto_excedente - ($monto_excedente * $socio->descuento / 100) ); //cuota mensual mas el excedente en caso de ser mas socios de lo permitido en el girpo fliar
            foreach ($socio_actividades['actividad'] as $actividad) {                
                $total = $total + ($actividad->precio - ($actividad->precio * $actividad->descuento /100) ); // actividades del tituloar del grupo familiar
            }
            foreach ($familiares as $familiar) {
                foreach($familiar['actividades']['actividad'] as $actividad){
                    $total = $total + ($actividad->precio - ($actividad->precio * $actividad->descuento /100) ); //actividades del los socios del griupo famlilar
                }
            }

            $financiacion = $this->get_financiado_mensual($socio->Id);            
            $f_total = 0;
            if($financiacion){
                foreach ($financiacion as $plan) {
                    $f_total = $f_total + round($plan->monto/$plan->cuotas,2);
                }                
            }

            $total = $total + $f_total;
            $cuota = array(
                "tid" => $sid,
                "titular" => $socio->apellido.' '.$socio->nombre,
                "total" => $total,
                "categoria" => 'Grupo Familiar',
                "cuota" => $monto,
                "familiares" => $familiares,
                "actividades" => $socio_actividades,
                "excedente" => $excedente,
                "monto_excedente" => $monto_excedente- ($monto_excedente * $socio->descuento / 100),
                "financiacion" => $financiacion,
                "descuento" => $socio->descuento,
                "cuota_neta"=>$cats[3]->precio
            );
            return $cuota;

        }else{ //si no esta en un grupo familiar
            $socio_actividades =  $this->get_actividades_socio($sid); //buscamos las actividades del socio
            $socio_cuota = $cats[$socio->categoria-1]->precio - ($cats[$socio->categoria-1]->precio * $socio->descuento / 100); //precio de la cuota
            $total = $socio_cuota; //cuota mensual
            foreach ($socio_actividades['actividad'] as $actividad) {
                $total = $total + $actividad->precio - ($actividad->precio * $actividad->descuento /100) ; //actividades del socio
            }

            $financiacion = $this->get_financiado_mensual($socio->Id);            
            $f_total = 0;
            if($financiacion){
                foreach ($financiacion as $plan) {
                    $f_total = $f_total + round($plan->monto/$plan->cuotas,2);
                }
            }


            $total = $total + $f_total;
            $cuota = array(
                "tid" => $sid,
                "titular" => $socio->apellido.' '.$socio->nombre,
                "total" => $total,
                "categoria" => $cats[$socio->categoria-1]->nomb,
                "cuota" => $socio_cuota,
                "familiares" => '0',
                "actividades" => $socio_actividades,
                "excedente" => '0',
                "monto_excedente" => '0',
                "financiacion" => $financiacion,
                "descuento" => $socio->descuento,
                "cuota_neta"=>$cats[$socio->categoria-1]->precio
            );
        return $cuota;
        }                
    }
    function get_actividades_socio($sid){
        $this->load->model("socios_model");  //buscamos datos del socio
        $socio = $this->socios_model->get_socio($sid);
        $this->load->model("actividades_model"); //buscamos las actividades del socio
        $actividades = $this->actividades_model->get_act_asoc($sid);
        $act = array();
        foreach ($actividades as $actividad) {
                
                    if($actividad->estado != '0'){
                        $act[] = $actividad;
                    }
                }        
        $actividades_socio = array('actividad' =>$act);  
        return $actividades_socio; // devolvemos los datos de la actividad y el usuario correspondiente
    }
    function generar_cupon($sid, $monto)
    {
        $this->db->where('sid',$sid); // ponemos en 0 todos los cupones de este socio
        $this->db->update('cupones',array('estado'=>'0'));        
        $data = array(
                'sid' => $sid,
                'monto' => $monto,
                'estado' => '1'
            );
        $this->db->insert('cupones',$data);
        return $this->db->insert_id();
    }
    public function get_socio_total($sid)
    {
        $this->db->where('sid',$sid);        
        $this->db->order_by('Id','desc');
        $fact = $this->db->get('facturacion');
        if($fact->num_rows() == 0){return false;}
        /*$total = 0;
        foreach ($fact->result() as $f) {
            $total = $total + $f->haber;
            $total = $total - $f->debe;
        }*/
        $total = $fact->row()->total;
        return $total;
    }

    public function get_socio_total2($sid)
    {        
        $this->db->where('tutor_id',$sid);        
        $this->db->where('tipo !=',5);
        $this->db->where('estado',1);    
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;} 
        $total = 0;
        foreach ($query->result() as $pago) {
            $total = $total + $pago->monto;
            $total = $total - $pago->pagado;
        }
        return $total;
    }


    public function insert_facturacion($data)
    {
        $this->db->insert('facturacion',$data);
    }
    public function insert_facturacion_cron()
    {
        $this->db->insert('facturacion_cron',array('des'=>'0'));
    }
    public function check_cron()
    { //comprueba si ya se ejecuto la tarea este mes
        $this->db->where(date('Y'), 'YEAR(date)' , FALSE);
        $this->db->where(date('m'), 'MONTH(date)' , FALSE);        
        $query = $this->db->get('facturacion_cron');
        if($query->num_rows() == 0){
            return false;
        }else{
            return true;
        }
    }
    public function get_facturacion($sid)
    {
        $this->db->order_by('Id','desc');      
        $this->db->where("sid", $sid);
        $query = $this->db->get('facturacion');
        return $query->result();
    }
    public function check_cron_pagos()
    { //comprueba si ya se ejecuto la tarea hoy
        $this->db->where(date('Y'), 'YEAR(date)' , FALSE);
        $this->db->where(date('m'), 'MONTH(date)' , FALSE);
        $this->db->where(date('d'), 'DAY(date)' , FALSE);
        $query = $this->db->get('pagos_cron');
        if($query->num_rows() == 0){
            return false;
        }else{
            return true;
        }
    }
    public function insert_pagos_cron($fecha)
    {
        $this->db->insert('pagos_cron',array('date'=>$fecha,'des'=>'0'));
    }
    public function insert_pago($pago)
    {
        $total = $this->get_deuda($pago['sid']);        
        $total = $total + $pago['monto'];
        $descripcion = "Pago acreditado desde: CuentaDigital <br>Fecha: ".$pago['fecha'].' '.$pago['hora'];
        $this->db->insert('facturacion',array('sid'=>$pago['sid'],'haber'=>$pago['monto'],'total'=>$total,'descripcion'=>$descripcion));

    }
    public function registrar_pago($tipo,$sid,$monto,$des,$actividad)
    {
        $total = $this->get_socio_total($sid);  
            
        if($tipo == 'debe'){
            $debe = $monto;
            $haber = '0.00';
            $total = $total - $debe;
            if($actividad == 'cs'){
                $aid = 0;
                $tipo = 1;
            }else{
                $aid = $actividad;
                $tipo = 4;
            }
            $pago = array(
                'sid' => $sid,  
                'tutor_id' => $sid,                  
                'aid' => $aid,
                'generadoel' => date('Y-m-d'),
                'descripcion' => $des,
                'monto' => $monto,
                'tipo' => $tipo,
                );
            $this->pagos_model->insert_pago_nuevo($pago);
            $this->registrar_pago2($sid,0);
        }else{
            $haber = $monto;
            $debe = '0.00';
            $total = $total + $haber;
            $this->registrar_pago2($sid,$monto);
        }
        $data = array(
                "sid" => $sid,
                "descripcion" => $des,
                "debe" => $debe,
                "haber" => $haber,
                "total" => $total
            );
        $this->db->insert("facturacion",$data);
        $data['iid'] = $this->db->insert_id();
        $data['fecha'] = date('d/m/Y');
        $data = json_encode($data);
        return $data;
    }

    public function get_deuda($sid){        
        $this->db->where('sid',$sid);
        $this->db->order_by('Id','desc');
        $query = $this->db->get('facturacion');
        if($query->num_rows() == 0){ return 0;}
        $deuda = $query->row()->total;
        return $deuda;
    }

    public function financiar_deuda($socio,$monto,$cuotas,$detalle){
        $inicio = date('Y-m').'-1';
        $nuevafecha = strtotime ( '+'.$cuotas.' month' , strtotime ( $inicio ) ) ;
        $fin = date ( 'Y-m-d' , $nuevafecha );   
        $financiacion = array(
            'sid' => $socio,
            'cuotas' => $cuotas,
            'monto' => $monto,
            'inicio' => $inicio,
            'fin' => $fin,
            'detalle'=>$detalle
            );
        $this->db->insert('financiacion',$financiacion);
    }

    public function get_planes($sid){
        $this->db->where('sid',$sid);
        $query = $this->db->get('financiacion');
        $planes = $query->result();
        $query->free_result();
        return $planes;
    }

    public function cancelar_plan($id){
        $this->db->where('Id',$id);
        $this->db->update('financiacion',array('estado'=>2));
    }

    public function get_financiado_mensual($sid){
        $fecha = date('Y-m-d');
        $this->db->where('sid',$sid);
        $this->db->where('inicio <=',$fecha);
        $this->db->where('fin >',$fecha);        
        $this->db->where('estado',1);
        $query = $this->db->get('financiacion');
        if($query->num_rows() == 0){return false;}
        $planes = $query->result();
        $query->free_result();
        return $planes;
    }

    public function update_cuota($id){        
        $this->db->where('Id',$id);        
        $this->db->where('estado',1);
        $this->db->set('actual','actual+1',false);
        $this->db->update('financiacion');
    }

    public function get_morosos($meses=6,$actividad=null){        
        if(!$actividad || $actividad == '-1'){
            $this->db->select('Id,alta');
            $this->db->where('estado',1);
            $query = $this->db->get('socios');
            if($query->num_rows() == 0){return false;}
            $socios = $query->result();                     
        }else{
            $this->db->select('sid');
            $this->db->distinct();
            $this->db->where('aid',$actividad);
            $this->db->where('estado',1);
            $query = $this->db->get('actividades_asociadas');
            
            if($query->num_rows() == 0){return false;}
            $socios = $query->result();
            foreach ($socios as $socio) {
                $this->db->where('Id',$socio->sid);
                $query = $this->db->get('socios');
                $socio->alta = $query->row()->alta;
                $socio->Id = $socio->sid;
                unset($socio->sid);
            }      
        }
        $morosos = array();
        foreach ($socios as $socio) {
            //buscamos el ultimo pago del socio
            $deuda = 0;
            if($actividad != '-1'){
                //$this->db->order_by('pagadoel','desc');
                $this->db->where('estado',1);
                $this->db->where('sid',$socio->Id);
                $this->db->where('aid',$actividad);
                $query = $this->db->get('pagos');
                $m = $query->num_rows();
                $impagos = $query->result();
                foreach ($impagos as $impago) {
                    $deuda = $deuda + $impago->monto;
                }
                if(!$fecha = $this->get_ultimo_pago_actividad($actividad,$socio->Id)){
                    $fecha = 'Sin Registros';
                }else{
                    $fecha = $fecha->pagadoel;
                }
            }else{
                $this->db->where('estado',1);
                $this->db->where('sid',$socio->Id);
                $this->db->where('tipo',1);
                $query = $this->db->get('pagos');
                $m = $query->num_rows();
                $impagos = $query->result();
                foreach ($impagos as $impago) {
                    $deuda = $deuda + $impago->monto;
                }
                $fecha = $this->get_ultimo_pago_cuota($socio->Id);
                if(!$fecha){
                    $fecha = 'Sin Registros';
                }else{
                    $fecha = $fecha->pagadoel;
                }
            }

            if(@$m == @$meses){                
                $deuda = $deuda*-1;
                //var_dump($deuda);
                //die;
                if($deuda < 0){
                    $this->db->where('Id',$socio->Id);
                    $this->db->where('estado',1);
                    $query = $this->db->get('socios');
                    $socio = $query->row();

                    $moroso = new stdClass;                    
                    $moroso->Id = $socio->Id;
                    $moroso->nomb = $socio->nombre.' '.$socio->apellido;
                    $moroso->deuda = $deuda;                        
                    $moroso->pago = $fecha;                        
                    $morosos[] = $moroso;
                }
            }
        }        
        return $morosos;
    }

    public function get_pagos_actividad($act){
        $this->db->where('aid',$act);
        $this->db->where('estado',1);
        $query = $this->db->get('actividades_asociadas');
        $asoc = $query->result();
        $query->free_result();
        
        $this->load->model("socios_model");

        foreach ($asoc as $a) {
            $socio = $this->socios_model->get_socio($a->sid);    
            $a->Id = $socio->Id;        
            $a->socio = @$socio->nombre.' '.@$socio->apellido;
            $a->telefono = @$socio->telefono;
            $a->nacimiento = @$socio->nacimiento;
            $a->dni = @$socio->dni;
            $a->suspendido = @$socio->suspendido;
            $a->observaciones = @$socio->observaciones;
            $a->act_nombre = $this->actividades_model->get_actividad($a->aid)->nombre;            
            //@$a->deuda = $this->pagos_model->get_deuda($socio->Id);
            //@$a->deuda = $this->pagos_model->get_ultimo_pago_actividad($a->aid,$socio->Id);
            @$a->deuda = $this->pagos_model->get_deuda_actividad($a->aid,$socio->Id);
            @$a->cuota = $this->pagos_model->get_monto_socio($socio->Id)['total'];
            @$a->monto_adeudado = $this->pagos_model->get_socio_total($socio->Id);
        }
        return $asoc;
    } 

    public function get_pagos_profesor($id)
    {
        $this->db->where('profesor',$id);
        $query = $this->db->get('actividades');
        $actividades = $query->result();
        $socios = array();
        foreach ($actividades as $actividad) {
            $socios[] = $this->get_pagos_actividad($actividad->Id);
        }        
        return $socios;
    }

    public function get_usuarios_suspendidos()
    {
        $this->db->where('suspendido',1);
        $this->db->where('estado',1);
        $this->db->order_by('apellido','asc');
        $this->db->order_by('nombre','asc');
        $query = $this->db->get('socios');
        $socios = $query->result();
        foreach ($socios as $socio) {
            $socio->deuda_monto = $this->get_deuda($socio->Id);
        }
        $query->free_result();
        return $socios;
    }

    public function get_socios_activos($value='')
    {
        $this->db->where('suspendido',0);
        $this->db->where('estado',1);
        $this->db->order_by('apellido','asc');
        $this->db->order_by('nombre','asc');
        $query = $this->db->get('socios');
        $socios = $query->result();
        foreach ($socios as $socio) {
            $socio->deuda_monto = $this->get_deuda($socio->Id);
        }
        $query->free_result();
        return $socios;
    }

    public function get_pagos_categorias($id){
        $this->db->where('estado',1);
        $this->db->where('categoria',$id);
        $query = $this->db->get('socios');
        $socios = $query->result();

        foreach ($socios as $socio) {
            $socio->deuda_monto = $this->get_deuda($socio->Id);
            $socio->deuda = $this->pagos_model->get_ultimo_pago_socio($socio->Id);
            $socio->cuota = $this->pagos_model->get_monto_socio($socio->Id)['total'];
        }
        return $socios;

    }

    public function get_ingresos($fecha1='',$fecha2='')
    {    
        /*$this->db->order_by('facturacion.date','asc');
        $this->db->where('facturacion.date >=',$fecha1.' 0:00:00');
        $this->db->where('facturacion.date <=',$fecha2.' 23:59:59');
        $this->db->where('facturacion.haber >',0);
        $this->db->join('socios','socios.Id = facturacion.sid');
        $query = $this->db->get('facturacion');
        if($query->num_rows() == 0){return false;}
        $ingresos = $query->result();
        foreach ($ingresos as $ingreso) {
            $cuota = $acts = array();
            $this->db->where('estado',0);            
            $this->db->where('sid',$ingreso->sid);
            $this->db->where('pagadoel >=',$fecha1.' 0:00:00');
            $this->db->where('pagadoel <=',$fecha2.' 23:59:59');
            $query = $this->db->get('pagos');
            if($query->num_rows() != 0){
                $pagos = $query->result();
                foreach ($pagos as $pago) {
                    if($pago->tipo == 1 || $pago->tipo == 2 || $pago->tipo == 3){
                        $cuota[] = $pago;
                    }else if($pago->tipo == 4){
                        $acts[] = $pago;
                    }
                }
                $ingreso->cuota = $cuota;                
                $ingreso->acts = $acts;                
            }
        }
        $query->free_result();*/

        //$this->db->where('estado',0);            
        //$this->db->where('sid',$ingreso->sid);
        $this->load->model('socios_model');
        $this->db->where('pagadoel >=',$fecha1.' 0:00:00');
        $this->db->where('pagadoel <=',$fecha2.' 23:59:59');
        $this->db->where('estado',0);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){ return false; }
        $pagos = $query->result();
        foreach ($pagos as $pago) {
            $pago->socio = $this->socios_model->get_socio($pago->tutor_id);
        }        
        return $pagos;
    }

     public function get_ingresos_cuentadigital($fecha1='',$fecha2='')
    {            
        $this->load->model('socios_model');
        $this->db->where('fecha >=',$fecha1.' 0:00:00');
        $this->db->where('fecha <=',$fecha2.' 23:59:59');
        $query = $this->db->get('cuentadigital');
        if($query->num_rows() == 0){ return false; }
        $pagos = $query->result();
        foreach ($pagos as $pago) {
            $pago->socio = $this->socios_model->get_socio($pago->sid);
        }        
        return $pagos;
    }

    public function get_cobros_actividad($fecha1='',$fecha2='',$actividad=false,$categoria=false)
    {
        $this->load->model('actividades_model');
        $this->load->model('socios_model');
        $actividad = $this->actividades_model->get_actividad($actividad);
        //$this->db->select('sid');
        //$this->db->distinct();
        $this->db->where('estado',0);
        $this->db->where('aid',$actividad->Id);
        $this->db->where('pagadoel >=',$fecha1.' 0:00:00');
        $this->db->where('pagadoel <=',$fecha2.' 23:59:59');
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $pagos = $query->result();
        $res = array();
        foreach ($pagos as $pago) {
            $pago->socio = $this->socios_model->get_socio($pago->sid);
            $pago->deuda = $this->get_deuda_actividad($actividad->Id,$pago->sid);
            if($categoria != ''){
                if(date('Y',strtotime($pago->socio->nacimiento)) != $categoria){
                    continue;
                }                
            }    
            $res[] = $pago;           
        }                 
        return $res;
    }

    public function get_cobros_cuota($fecha1='',$fecha2='',$categoria=false)
    {        
        $this->load->model('socios_model');        
        //$this->db->select('sid');
        //$this->db->distinct();
        $this->db->where('estado',0);
        $this->db->where('tipo',1);
        $this->db->where('pagadoel >=',$fecha1.' 0:00:00');
        $this->db->where('pagadoel <=',$fecha2.' 23:59:59');
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $pagos = $query->result();
        $res = array();
        foreach ($pagos as $pago) {
            $pago->socio = $this->socios_model->get_socio($pago->sid);
            $pago->deuda = $this->get_deuda_cuota($pago->sid);
            if($categoria != ''){
                if(date('Y',strtotime($pago->socio->nacimiento)) != $categoria){
                    continue;
                }                
            }    
            $res[] = $pago;           
        }                 
        return $res;
    }

    public function insert_pago_nuevo($pago)
    {
        $this->db->insert('pagos',$pago);
    }


    public function registrar_pago2($sid=false,$monto='0')
    {
        if(!$sid){return false;}
        //$this->load->model('pagos_model');
        $this->db->where('tipo',5);
        $this->db->where('tutor_id ',$sid);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){
            $pago = array(
                'sid' => $sid, 
                'tutor_id' => $sid,
                'aid' => 0, 
                'generadoel' => date('Y-m-d'),
                'descripcion' => "A favor",
                'monto' => 0,
                'tipo' => 5,
            );
            $this->insert_pago_nuevo($pago);
            $a_favor = 0;
        }else{            
            $a_favor = $query->row()->monto;            
        }
        $monto = $monto + $a_favor*-1;
        

        $this->db->order_by('generadoel','asc');
        $this->db->order_by('tipo','asc');
        $this->db->where('tipo !=',5);        
        $this->db->where('monto >',0);        
        $this->db->where('tutor_id',$sid);
        $this->db->where('estado',1);
        $query = $this->db->get('pagos');
        foreach ($query->result() as $pago) {
            if($monto > 0){
                if( ($pago->monto - $pago->pagado) <= $monto){ 
                    if($pago->pagado == 0){
                        $pagado = $pago->monto;
                        $monto = $monto - $pagado;
                    }else{
                        $pagado = $pago->monto;
                        $monto = $monto - ($pago->monto - $pago->pagado);
                    }
                    $this->db->where('Id',$pago->Id);   
                    $this->db->update('pagos',array('pagado'=>$pagado,'estado'=>0,'pagadoel'=>date('Y-m-d H:i:s')));
                }else{
                    if($pago->pagado == 0){
                        $pagado = $monto;
                    }else{
                        $pagado = $pago->pagado+$monto;
                    }
                    $this->db->where('Id',$pago->Id);
                    $this->db->update('pagos',array('pagado'=>$pagado,'pagadoel'=>date('Y-m-d H:i:s')));
                    $monto = 0;        
                }                
            }
        }

        $this->db->where('tutor_id',$sid);
        $this->db->where('tipo',5);
        $this->db->update('pagos',array('monto'=>$monto*-1));

    }

    public function get_ultimo_pago_actividad($aid,$sid)
    {
        $this->db->order_by('pagadoel', 'desc');
        $this->db->where('aid',$aid);
        $this->db->where('tutor_id',$sid);
        $this->db->where('estado',0);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $ultimo_pago = $query->row();
        $query->free_result();
        return $ultimo_pago;
    }

    public function get_deuda_actividad($aid,$sid)
    {
        $this->db->order_by('generadoel', 'asc');
        $this->db->where('aid',$aid);
        $this->db->where('sid',$sid);
        $this->db->where('estado',1);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $ultimo_pago = $query->row();
        $query->free_result();
        return $ultimo_pago;
    }

    public function get_deuda_cuota($sid)
    {
        $this->db->order_by('generadoel', 'asc');
        $this->db->where('tipo',1);
        $this->db->where('sid',$sid);
        $this->db->where('estado',1);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $ultimo_pago = $query->row();
        $query->free_result();
        return $ultimo_pago;
    }

    public function get_ultimo_pago_cuota($sid='')
    {
        $this->db->order_by('pagadoel', 'desc');
        $this->db->where('tipo',1);
        $this->db->where('tutor_id',$sid);
        $this->db->where('estado',0);
        $query = $this->db->get('pagos');
        if($query->num_rows() == 0){return false;}
        $ultimo_pago = $query->row();
        $query->free_result();
        return $ultimo_pago;
    }

    public function get_ultimo_pago_socio($sid)
    {
        //$this->db->where('aid',$aid);
        $this->db->order_by('generadoel','asc');
        $this->db->where('tutor_id',$sid);
        $this->db->where('tipo !=',5);
        $this->db->where('tipo !=',4);
        $this->db->where('tipo !=',2);
        $this->db->where('estado',1);
        $query = $this->db->get('pagos',1);
        if($query->num_rows() == 0){return false;}
        $ultimo_pago = $query->row();
        $query->free_result();
        return $ultimo_pago;
    }

    public function get_pagos_actividad_anterior($act){
        $this->db->where('aid',$act);
        $this->db->where('estado',1);
        $query = $this->db->get('actividades_asociadas');
        $asoc = $query->result();
        $query->free_result();
        
        $this->load->model("socios_model");

        foreach ($asoc as $a) {
            $socio = $this->socios_model->get_socio($a->sid); 
            $a->Id = $socio->Id;           
            $a->socio = @$socio->nombre.' '.@$socio->apellido;
            $a->telefono = @$socio->telefono;
            $a->nacimiento = @$socio->nacimiento;
            $a->dni = @$socio->dni;
            $a->suspendido = @$socio->suspendido;
            $a->act_nombre = $this->actividades_model->get_actividad($a->aid)->nombre;            
            //@$a->deuda = $this->pagos_model->get_deuda($socio->Id);
            $a->deuda = 0;
            $this->db->where('sid',$a->Id);
            $this->db->where('tipo',1);
            $this->db->where('monto >',0);
            $this->db->where('descripcion','Deuda Anterior');
            //$this->db->where('generadoel <','2015-05-01 00:00:00');
            $query = $this->db->get('pagos');
            if($query->num_rows != 0){
                $a->deuda = $query->row()->estado;                
            }
        }
        return $asoc;
    }

    public function get_socios_financiados()
    {        
        $this->db->where('fn.estado',1);
        $this->db->join('socios','socios.Id = fn.sid');
        $query = $this->db->get('financiacion as fn');
        if($query->num_rows() == 0){ return false; }
        $socios = $query->result();
        $query->free_result();
        return $socios;
    }

    public function get_becas($actividad='')
    {
        if($actividad == -1){
            $this->db->where('descuento >',0);
            $this->db->where('estado',1);
            $query = $this->db->get('socios');
            if($query->num_rows() == 0){ return false; }
            $socios = $query->result();
            $query->free_result();
            return $socios;
        }else{
            $this->db->select('aa.*, socios.*, aa.descuento as descuento, socios.Id as Id');
            $this->db->where('aa.aid',$actividad);
            $this->db->where('aa.descuento >',0);
            $this->db->where('aa.estado',1);
            $this->db->join('socios', 'socios.Id = aa.sid', 'left');
            $query = $this->db->get('actividades_asociadas as aa');
            if($query->num_rows() == 0){ return false; }
            $socios = $query->result();
            $query->free_result();
            return $socios;
        }
    }

    public function get_sin_actividades()
    {
        $this->load->model('socios_model');
        $socios = $this->socios_model->get_socios();
        $sin_actividades = array();
        foreach ($socios as $socio) {
            $this->db->where('sid', $socio->Id);
            $this->db->where('estado',1);
            $query  = $this->db->get('actividades_asociadas');
            if( $query->num_rows() == 0 ){
                $sin_actividades[] = $socio;
            }
        }
        return $sin_actividades;
    }
    
    public function insert_cuentadigital($pago='')
    {
        $this->db->insert('cuentadigital',$pago);
    }

    public function get_pagos_edit($socio_id)
    {
        $this->db->select('pagos.*,actividades.nombre');
        $this->db->where('pagos.tutor_id', $socio_id);
        $this->db->where('pagos.generadoel >=',date('Y-m').'-01');
        $this->db->join('actividades', 'actividades.Id = pagos.aid', 'left');
        $query = $this->db->get('pagos');
        if( $query->num_rows() == 0 ){ return false; }
        $pagos = $query->result();
        $query->free_result();
        return $pagos;
    }

    public function eliminar_pago($id)
    {
        $this->db->where('pagos.Id',$id);
        $this->db->join('actividades', 'actividades.Id = pagos.aid', 'left');
        $query = $this->db->get('pagos');
        if( $query->num_rows() == 0 ){ return false; }
        $pago = $query->row();

        //actualizamos saldo a favor
        $a_favor = $pago->pagado;
        if($a_favor > 0){
            $this->db->where('tutor_id', $pago->tutor_id);
            $this->db->where('tipo', 5);
            $this->db->set('monto', 'monto-'.$a_favor, FALSE);
            $this->db->update('pagos');            
        }

        //actualizamos facturacion
        $facturacion = $pago->monto;
        if($facturacion > 0){
            switch ($pago->tipo) {
                case 1:
                    $descripcion = 'Cuota Social - '.date('d/m/Y',strtotime($pago->generadoel));
                    break;
                
                case 2:
                    $descripcion = 'Recargo por Mora - '.date('d/m/Y',strtotime($pago->generadoel));
                    break;

                case 3:
                    $descripcion = 'Financiación de deuda - '.date('d/m/Y',strtotime($pago->generadoel));
                    break;

                case 4:
                    $descripcion = 'Actividad: '.$pago->nombre.' - '.date('d/m/Y',strtotime($pago->generadoel));
                    break;      
            }
            $total = $this->get_socio_total($pago->tutor_id);
            $facturacion = array(
                'sid' => $pago->tutor_id, 
                'descripcion'=> "CORRECCIÓN MANUAL DE PAGOS: ".$descripcion,
                'debe'=>0,
                'haber'=>$facturacion,
                'total'=>$total+$facturacion
            );
            $this->db->insert('facturacion', $facturacion);
        }

        $this->db->where('Id', $id);
        $this->db->delete('pagos');
        $query->free_result();
        return $pago->tutor_id;
    }
}

