<iframe src="<?=base_url()?>imprimir" id="iframe1" scrolling="no" width="100%" height="600" frameborder="0"></iframe>
<script language="JavaScript">
<!--
function autoResize(id){
    var newheight;
   

    if(document.getElementById){
        newheight=document.getElementById(id).contentWindow.document .body.scrollHeight;   
    }

    document.getElementById(id).style.height= (newheight) + "px";    
}
//-->
</script>