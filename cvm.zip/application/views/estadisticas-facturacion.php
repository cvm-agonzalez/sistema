<div class="page page-charts ng-scope" data-ng-controller="morrisChartCtrl">
    <div class="row">
        <div class="col-md-12">
            <section class="panel panel-default">
                <div class="panel-heading">
                	<span class="glyphicon glyphicon-th"></span> FACTURACIÓN MENSUAL
                	<span class="pull-right">
                    </span>
                </div>
                <div class="panel-body">                   
  					<div id="facturacion-mensual"></div>
				</div>               
            </section>            
        </div>
		<div class="col-md-12">
            <section class="panel panel-default">
                <div class="panel-heading">
                	<span class="glyphicon glyphicon-th"></span> FACTURACIÓN ANUAL               
                </div>
                <div class="panel-body">                   
  					<div id="facturacion-anual"></div>
				</div>               
            </section>            
        </div>        
    </div>
</div>    