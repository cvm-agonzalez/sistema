<div class="container" style="margin-top:50px;">
    <div class="starter-template">
        <h1>Socios</h1>
        <div id="actividades_print">
	        <div class="col-xs-6">
	        	<label>Activos/Suspendidos:</label>
	        	<select class="form-control" id="socios_select"> 
	        		<option value="activos">Activos</option>	        		
	        		<option value="suspendidos">Suspendidos</option>	        		
	    		</select>
	    	</div>
	    	<div class="clearfix"></div>
	    </div>

    	<div id="listado_socios">
    		<i class="fa fa-spinner fa-spin"></i> Generando Listado	
	        
		</div>
  	</div>

</div><!-- /.container -->