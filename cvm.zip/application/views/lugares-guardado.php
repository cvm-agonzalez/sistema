  <div class="page page-table" data-ng-controller="tableCtrl">
    <div class="panel panel-default table-dynamic">
        <div class="panel-heading"><strong><span class="fa fa-user"></span> LUGARES</strong></div>
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12">
                    <h4>El lugar se guardó correctamente.</h4>
                    <a class="btn btn-primary" href="<?=$baseurl?>admin/actividades/lugares">Volver al Listado de Lugares</a> 
                    <a class="btn btn-success" href="<?=$baseurl?>admin/actividades/lugares/editar/<?=$pid?>">Editar este Lugar</a>                        
                </div>
            </div>
        </div>
    </div>
  </div>