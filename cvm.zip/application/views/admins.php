                    <div class="page page-profile">
                        <div class="panel panel-default">
                            <div class="panel-heading"><strong><span class="fa fa-user"></span> ADMINISTRADORES</strong></div>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nombre de Usuario</th>
                                        <th>E-Mail</th>
                                        <th>Última conexión</th>
                                        <th>Opciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <? foreach($listaAdmin as $aa){ ?>
                                    <tr>
                                        <td><?=$aa->Id?></td>
                                        <td><span class="color-success"><?=$aa->user?></td>
                                        <td><?=$aa->mail?></td>
                                        <td><span class="label label-info"><?=$aa->lCon?></span></td>
                                        <td>
                                            <a href=""><i class="fa fa-gear"></i> Editar</a>  | 
                                            <a href=""><i class="fa fa-times"></i> Eliminar</a>
                                        </td>
                                    </tr>                                    
                                    <? } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
<section class="page page-profile">
    <div class="panel panel-default">
        <div class="panel-heading"><strong><span class="fa fa-plus"></span> Agregar Administrador</strong></div>
        <div class="panel-body">
            <form class="form-horizontal ng-pristine ng-valid" action="<?=$baseurl?>admin/admins/agregar" method="post">

                <div class="form-group">
                    <label for="" class="col-sm-2">Nombre de usuario</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-2">E-Mail</label>
                    <div class="col-sm-10">
                        <input type="mail" class="form-control">
                    </div>
                </div>    
                <div class="form-group">
                    <label for="" class="col-sm-2">Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control">
                    </div>
                </div> 
                <div class="form-group">
                    <label for="" class="col-sm-2">Tipo</label>
                    <div class="col-sm-10">
                        <select style="padding:5px;">
                            <option>-- Elegir -- </option>
                            <option>General</option>
                            <option>Consultas</option>
                            <option>Pagos</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Agregar</button>
            </form>
        </div>
    </div>
</section>                    