<section class="page page-profile">
    <div class="panel panel-default">
        <div class="panel-heading"><strong><span class="fa fa-question-circle"></span> SOPORTE</strong></div>
        <div class="panel-body">
        	Su consulta fue enviada correctamente. <br>
            En unos instantes nos pondremos en contacto con Usted.            
       	</div>
    </div>
</section>