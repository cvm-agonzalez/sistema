  <div class="page page-table" data-ng-controller="tableCtrl">
    <div class="panel panel-default table-dynamic">
      <div class="panel-heading"><strong><span class="fa fa-user"></span> FACTURACIÓN MENSUAL</strong></div>
      	<div align="center" style="padding:30px;">
      		<h3>Generar Facturación Mensual</h3>
      		<button id="generar" class="btn-success">Aceptar</button>
      	</div>
        
    </div>
  </div>