<style>
.sortable-list {
	background-color: #EEE;
	list-style: none;
	margin: 0;
	min-height: 60px;
	padding: 10px;
}
.sortable-item {
	background-color: #FFF;
	border: 1px solid #000;	
	display: block;
	font-weight: bold;
	margin-bottom: 5px;
	padding: 20px 0;
	text-align: center;
}
.baja{
	background-color: #FF495F;
	color:#FFF;
}
</style>
<div class="row" id="lista">
	<div class="col-lg-6">
		<div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Actividades Asociadas</h3>
            </div>
            <div class="panel-body">            	
                <ul class="sortable-list" id="actividades_si">
                <? 
                $actividades_asociadas = array();
                foreach ($actividades_asoc as $actividad){                                
                	if($actividad->estado == '1'){
                		$actividades_asociadas[] = $actividad->Id; 		
                	}                
                ?>                	
					<li class="sortable-item <? if($actividad->estado == '0'){ echo 'baja'; } ?>" id="asoc_<?=$actividad->asoc_id?>">
						<div class="pull-right cruz" id="cruz_<?=$actividad->asoc_id?>" style="margin-top:-20px;">
							<?
							if($actividad->estado != '0'){ 
							?>
								<strong>Fecha de Alta:</strong> <?=$actividad->alta?><br>
								<a href="#" style="color:green" class="actividad_beca" id="actividad_beca_<?=$actividad->asoc_id?>" data-id="<?=$actividad->asoc_id?>" data-beca="<?=$actividad->descuento?>">									
									Configurar Beca
								</a><br>
								<a href="#" id="quitar_actividad" onclick="quitar_act('<?=$actividad->asoc_id?>','<?=$actividad->Id?>')" data-id="<?=$actividad->asoc_id?>">									
									Dar de Baja <i class="fa fa-times"></i>
								</a>
							<?
							}else{
							?>
								
									<strong>Fecha de Alta:</strong> <?=$actividad->alta?><br>
									<strong>Fecha de Baja:</strong> <?=$actividad->baja?>
								
							<?
							}
							?>
						</div>						
						#<span><?=$actividad->Id?> <?=$actividad->nombre?>
						<?
						if($actividad->descuento > 0){
						?>
							&nbsp;<label class="label label-info">Beca <?=$actividad->descuento?>%</label>
						<? } ?>
						</span>
					</li>				
				<? } ?>
				</ul>
            </div>
        </div>
	</div>
	<div class="col-lg-6">
		<div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Actividades NO Asociadas</h3>
            </div>
            <div class="panel-body">
            	Buscar Actividad: <input class="form-control" type="text" id="activ"><br>            	
                <ul class="sortable-list" id="actividades_no">
                <? foreach ($actividades as $actividad){ 
                	if(!in_array($actividad->Id, $actividades_asociadas)){
                	?>
					<li class="sortable-item" id="no_asoc_<?=$actividad->Id?>">
						<div class="pull-left " style="margin-top:-5px; margin-left:5px;">
							<a class="btn btn-success" href="#" id="asociar_actividad" data-id="<?=$actividad->Id?>">
								<i class="fa fa-arrow-left"></i>
							</a>
						</div>
						#<span><?=$actividad->Id?> <?=$actividad->nombre?>

						</span>
					</li>
				<? 
					}	
				} 
				?>
				</ul>
				
            </div>
        </div>
	</div>
</div>
<script type="text/javascript">
		
		$.extend($.expr[":"], {
			"containsIN": function(elem, i, match, array) {
				return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
			}
		});
		$("#activ").keyup(function(){
            var filter = $(this).val();
            var list = $("#actividades_no");
            if(filter) {
              // this finds all links in a list that contain the input,
              // and hide the ones not containing the input while showing the ones that do
              $(list).find("span:not(:containsIN(" + filter + "))").parent().slideUp();
              $(list).find("span:containsIN(" + filter + ")").parent().slideDown();
            } else {
              $(list).find("li").slideDown();
            }
            return false;
        })

        .keyup( function () {
            // fire the above change event after every letter
            $(this).change();
        });

        /*$("a#quitar_actividad").click(function(){
        	var agree= confirm("Seguro que desea dar de baja esta actividad para este usuario?");
        	if(agree){
	        	var id = $(this).data('id');
	        	$("#asoc_"+id).addClass('baja');
	        	$(this).hide();	        
	        	$.get("<?=$baseurl?>admin/actividades/baja/<?=$sid?>/"+id);
	        }else{
	        	return false;
	        }
        })*/

        $("a#asociar_actividad").click(function(){
        	var agree= confirm("Seguro que desea asociar esta actividad a este usuario?");
        	if(agree){
	        	var id = $(this).data('id');
	        	$("#no_asoc_"+id).slideUp();
	        	var facturar = 'false';
	        	var fecha = new Date();
	        	fecha = fecha.getDate();	        	
        		if(fecha < 25){
	        		var agree= confirm("Desea que esta actividad sea facturada?");
	        		if(agree){
	        			facturar = 'true';
	        		}
        		}
	        	$.get("<?=$baseurl?>admin/actividades/alta/<?=$sid?>/"+id+"/"+facturar,function(data){
	        		var actividad = $.parseJSON(data);
	        		var newLi = '<li class="sortable-item" id="asoc_'+actividad.asoc_id+'"><div class="pull-right cruz" id="cruz_'+actividad.asoc_id+'" style="margin-top:-20px;">Fecha de Alta: '+actividad.alta+'<br> <a href="#" style="color:green" class="actividad_beca" id="actividad_beca_'+actividad.asoc_id+'" data-id="'+actividad.asoc_id+'" data-beca="0">Configurar Beca</a><br><a href="#" onclick="quitar_act('+actividad.asoc_id+','+actividad.Id+')" id="quitar_actividad" data-id="'+actividad.asoc_id+'">Dar de Baja <i class="fa fa-times"></i></a></div>#<span>'+actividad.Id+' '+actividad.nombre+'</span></li>';
	        	$( newLi ).prependTo( $("#actividades_si") ); 
	        	});
        	}else{
        		return false;	
        	}
        })
        function quitar_act(id,aid){ 
            var agree= confirm("Seguro que desea dar de baja esta actividad para este usuario?");
        	if(agree){

	        	$("#asoc_"+id).addClass('baja');	        	
	        	$("#no_asoc_"+aid).slideDown();
	        	$("#cruz_"+id).html('');    
	        	$.get("<?=$baseurl?>admin/actividades/baja/<?=$sid?>/"+id,function(data){
	        		var actividad = $.parseJSON(data);
	        		console.log(id);
	        		$("#cruz_"+actividad.asoc_id).html('Fecha de Alta: '+actividad.alta+'<br>Fecha de Baja: '+actividad.baja); 
	        	});
	        }else{
	        	return false;
	        }
        }

        
</script>
