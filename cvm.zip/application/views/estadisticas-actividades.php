<div class="page page-charts ng-scope" data-ng-controller="morrisChartCtrl">
    <div class="row">
        <div class="col-md-12">
            <section class="panel panel-default">
                <div class="panel-heading">
                	<span class="glyphicon glyphicon-th"></span> ACTIVIDADES MENSUAL
                	
                </div>
                <div class="panel-body">
                	<div id="actividades-mensual"></div>
				</div>               
            </section>            
        </div>
		<div class="col-md-12">
            <section class="panel panel-default">
                <div class="panel-heading">
                	<span class="glyphicon glyphicon-th"></span> ACTIVIDADES ANUAL               
                </div>
                <div class="panel-body">                   
  					<div id="actividades-anual"></div>
				</div>               
            </section>            
        </div>        
    </div>
</div>    