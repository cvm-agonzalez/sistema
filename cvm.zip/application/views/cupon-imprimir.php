
<div align="center">
	<img src="<?=$baseurl?>images/cupones/<?=$cupon->Id?>.png"><br><br>
	<span style="font-family:Arial; font-size:12px;">Valor de la Cuota: $ <?=$cupon->monto?></span>
</div>

<script type="text/javascript">
window.print();
window.onfocus=function(){ window.close();}
</script>