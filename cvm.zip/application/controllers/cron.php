<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Cron extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        if($_GET['order'] != 'asdqwe'){exit('No Permitido');}
        $this->load->helper('url');
    }

	function index()
	{
		return false;
	}

	function facturacion(){ // esta funcion genera la facturacion del mes el dia 20
		$this->load->model("pagos_model");
		if($this->pagos_model->check_cron()){exit('Esta tarea ya fue ejecutada este mes.');}
        $this->pagos_model->insert_facturacion_cron();
		//checkeamos que se hayan ejecutado los cron de todos los dias

		//checkeamos que se hayan ejecutado los cron de todos los dias

		$this->load->model("socios_model");
		$socios = $this->socios_model->listar(); //listamos todos los socios activos		
		
		$cumpleanios = $this->socios_model->get_cumpleanios(); //buscamos los que cumplen 18 años
		foreach ($cumpleanios as $menor) {
			$this->socios_model->actualizar_menor($menor->Id); //los quitamos del grupo familiar y cambiamos la categoria a mayor
		}

		$socios = $this->socios_model->get_socios_pagan();

		//mail
		
        /*$config['charset'] = 'utf-8';                
        $config['mailtype'] = 'html';
        $this->email->initialize($config);*/
        //mail        
		foreach ($socios as $socio) {
			//var_dump($socio);	
			$cuota = $this->pagos_model->get_monto_socio($socio->Id);
			
			$descripcion = '<strong>Categoría:</strong> '.$cuota['categoria'];
			if($cuota['categoria'] == 'Grupo Familiar'){
				$descripcion .= '<br><strong>Integrantes:</strong> ';
				foreach ($cuota['familiares'] as $familiar) {
		    		$descripcion .= "<li>".$familiar['datos']->nombre." ".$familiar['datos']->apellido."</li>";
		    	}
			}
			$descripcion .= '<br><strong>Detalles</strong>:<br>';
			$descripcion .= 'Cuota Mensual '.$cuota['categoria'].' -';
            if($cuota['descuento'] > 0.00){
                $descripcion .= "$ ".$cuota['cuota_neta']." &nbsp;<label class='label label-info'>".$cuota['descuento']."% BECADO</label>";
            }
            $descripcion .= '$ '.$cuota['cuota'].'<br>';

            $pago = array(
                'sid' => $socio->Id, 
                'tutor_id' => $socio->Id,
                'aid' => 0, 
                'generadoel' => date('Y-m-d'),
                'descripcion' => $descripcion,
                'monto' => $cuota['cuota'],                
                'tipo' => 1,                
                );
            $this->pagos_model->insert_pago_nuevo($pago);

			foreach ($cuota['actividades']['actividad'] as $actividad) {	       
                $descripcion .= 'Cuota Mensual '.$actividad->nombre.' - $ '.$actividad->precio;
                if($actividad->descuento > 0){
                    $valor = $actividad->precio - ($actividad->precio * $actividad->descuento / 100);
                    $descripcion .= '&nbsp; <label class="label label-info">'.$actividad->descuento.'% BECADO</label> $ '.$valor;                    
                }
                $descripcion .= '<br>';
	        	$des = 'Cuota Mensual '.$actividad->nombre.' - $ '.$actividad->precio;
                if($actividad->descuento > 0){
                    $des .= '<label class="label label-info">'.$actividad->descuento.'% BECADO</label> $ '.$valor;
                }
                $des .= '<br>';

                $pago = array(
                    'sid' => $socio->Id,
                    'tutor_id' => $socio->Id,
                    'aid' => $actividad->Id,
                    'generadoel' => date('Y-m-d'),
                    'descripcion' => $des,
                    'monto' => $actividad->precio - ($actividad->precio * $actividad->descuento / 100),
                    'tipo' => 4,
                    );
                if($pago['monto'] <= 0){                    
                    $pago['estado'] = 0;
                    $pago['pagadoel'] = date('Y-m-d G:i:s');
                }
                $this->pagos_model->insert_pago_nuevo($pago);
	        } 
	        if($cuota['familiares'] != 0){
               	foreach ($cuota['familiares'] as $familiar) {
               		foreach($familiar['actividades']['actividad'] as $actividad){		               		
                    $descripcion .= 'Cuota Mensual '.$actividad->nombre.' ['.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.'] - $ '.$actividad->precio;
                    if($actividad->descuento > 0){
                        $valor = $actividad->precio - ($actividad->precio * $actividad->descuento / 100);
                        $descripcion .= '&nbsp; <label class="label label-info">'.$actividad->descuento.'% BECADO</label> $ '.$valor;                    
                    }
                    $descripcion .= '<br>';
	               	$des = 'Cuota Mensual '.$actividad->nombre.' ['.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.'] - $ '.$actividad->precio;
                    if($actividad->descuento > 0){
                        $valor = $actividad->precio - ($actividad->precio * $actividad->descuento / 100);
                        $des .= '&nbsp; <label class="label label-info">'.$actividad->descuento.'% BECADO</label> $ '.$valor;                    
                    }
                    $des = '<br>';	 

                    $pago = array(
                        'sid' => $familiar['datos']->Id,
                        'tutor_id' => $socio->Id,
                        'aid' => $actividad->Id,
                        'generadoel' => date('Y-m-d'),
                        'descripcion' => $des,
                        'monto' => $actividad->precio - ($actividad->precio * $actividad->descuento / 100),
                        'tipo' => 4,
                        );
                    $this->pagos_model->insert_pago_nuevo($pago);
               		}
               	}
           	}
           	if($cuota['excedente'] >= 1){
                $descripcion .= 'Socio Extra (x'.$cuota['excedente'].') - $ '.$cuota['monto_excedente'].'<br>';
	         	$des = 'Socio Extra (x'.$cuota['excedente'].') - $ '.$cuota['monto_excedente'].'<br>';
                $pago = array(
                    'sid' => $socio->Id,    
                    'tutor_id' => $socio->Id,                
                    'aid' => 0,
                    'generadoel' => date('Y-m-d'),
                    'descripcion' => $des,
                    'monto' => $cuota['monto_excedente'],
                    'tipo' => 1,
                    );
                $this->pagos_model->insert_pago_nuevo($pago);
			}

			//financiacion de deuda
			$deuda_financiada = 0;
			$planes = $this->pagos_model->get_financiado_mensual($socio->Id);


            if($planes){
    			foreach ($planes as $plan) {                
                    $descripcion .= 'Financiación de Deuda ('.$plan->detalle.' - Cuota: '.$plan->actual.'/'.$plan->cuotas.') - $ '.round($plan->monto/$plan->cuotas,2).'<br>';
    				
                    $des = 'Financiación de Deuda ('.$plan->detalle.' - Cuota: '.$plan->actual.'/'.$plan->cuotas.') - $ '.round($plan->monto/$plan->cuotas,2).'<br>';
                    $pago = array(
                        'sid' => $socio->Id,  
                        'tutor_id' => $socio->Id,                  
                        'aid' => 0,
                        'generadoel' => date('Y-m-d'),
                        'descripcion' => $des,
                        'monto' => round($plan->monto/$plan->cuotas,2),
                        'tipo' => 3,
                        );
                    $this->pagos_model->insert_pago_nuevo($pago);

    				$deuda_financiada = $deuda_financiada + round($plan->monto/$plan->cuotas,2);
                    $this->pagos_model->update_cuota($plan->Id);
    			}
                $deuda_financiada = round($deuda_financiada,2);
            }else{
                $deuda_financiada = 0;                
            }
            //end financiacion de deuda	
	        $total = $this->pagos_model->get_socio_total($socio->Id);
	        $total = $total - ($cuota['total']);
			$data = array(
				"sid" => $socio->Id,
				"descripcion" => $descripcion,
				"debe" => $cuota['total'],
				"haber" => '0',
				"total" => $total
			);

            $deuda = $this->pagos_model->get_deuda($socio->Id);

			$this->pagos_model->insert_facturacion($data);
			

			//mail
			$mail = $this->socios_model->get_resumen_mail($socio->Id);

            $cuota3 = $mail['resumen'];            
            $cuerpo = '<p><img src="http://clubvillamitre.com/images/vm-head.png" alt="" /></p>';
            $cuerpo .= '<h3><strong>Titular:</strong> '.$cuota3['titular'].'</h3>';

            if($deuda != 0){
                if($deuda < 0 ){
                    $cuerpo .= "Su deuda actual es de $ ".abs($deuda);
                }else{
                    $cuerpo .= "Usted posee un saldo a favor de $ ".abs($deuda);                
                }                
            }
            $cuerpo .= "<h4>Cuota Mensual</h4>";
            $cuerpo .= '<h5><strong>Categor&iacute;a:</strong> '.$cuota3['categoria'].'</h5>';
            
            if($cuota3['categoria'] == 'Grupo Familiar'){
           
                $cuerpo .= '<h5><strong>Integrantes</strong></h5><ul>';
                foreach ($cuota3['familiares'] as $familiar) {          
                    $cuerpo .= '<li>'.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.'</li>';                    
                }                    
                $cuerpo .= '</ul>';            
            }
            
            $cuerpo .= '<table class="table table-hover" width="100%;" border="0" style="font-family: "Arial";">
                <thead>
                    <tr style="background-color: #666 !important; color:#FFF;">                        
                        <th style="padding:5px;" align="left">Descripci&oacute;n</th>
                        <th style="padding:5px;" align="left">Monto</th>                        
                    </tr>
                </thead>
                <tbody>
                    <tr style="background: #CCC;">
                        <td style="padding: 5px;">Cuota Mensual '.$cuota3['categoria'].'</td>
                        <td style="padding: 5px;">$ '.$cuota3['cuota'].'</td>
                    </tr>';
                    foreach ($cuota3['actividades']['actividad'] as $actividad) {
                    $cuerpo .= '<tr style="background: #CCC;">
                        <td style="padding: 5px;">Cuota Mensual '.$actividad->nombre.'</td>
                        <td style="padding: 5px;">$ '.$actividad->precio.'</td>
                    </tr>';                        
                    } 
                    if($cuota3['familiares'] != 0){
                        foreach ($cuota3['familiares'] as $familiar) {
                            foreach($familiar['actividades']['actividad'] as $actividad){                           
                            
                            $cuerpo .= '<tr style="background: #CCC;">                    
                                <td style="padding: 5px;">Cuota Mensual '.$actividad->nombre.' ['.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.' ]</td>
                                <td style="padding: 5px;">$ '.$actividad->precio.'</td>
                            </tr>';
                            }                                   
                        }
                    }
                    if($cuota3['excedente'] >= 1){
                    
                    $cuerpo .='<tr style="background: #CCC;">                    
                                <td style="padding: 5px;">Socio Extra (x'.$cuota3['excedente'].')</td>
                                <td style="padding: 5px;">$ '.$cuota3['monto_excedente'].'</td>
                            </tr>';                        
                    }
                    if($cuota3['financiacion']){
                        foreach ($cuota3['financiacion'] as $plan) {                 
                    
                            $cuerpo .= '<tr style="background: #CCC;">                    
                                <td style="padding: 5px;">Financiación de Deuda ('.$plan->detalle.')</td>
                                <td style="padding: 5px;">$ '.round($plan->monto/$plan->cuotas,2).'</td>
                            </tr>';
                    
                        }
                    }
                    if($cuota3['descuento'] != 0.00){                        
                        $cuerpo .= '<tr style="background: #CCC;">                    
                                <td style="padding: 5px;">Descuento sobre cuota social</td>
                                <td style="padding: 5px;">'.$cuota3['descuento'].'%</td>
                            </tr>';                        
                    }
                    $cuerpo .= '
                </tbody>
                <tfoot>
                    <tr>                        
                        <th>Total</th>
                        <th>$ '.$cuota3['total'].'</th>                        
                    </tr>
                </tfoot>
            </table>';
            
            // cupon
            $this->load->model('pagos_model');
            $cupon = $this->pagos_model->get_cupon($mail['sid']);
            if($cupon->monto == $cuota3['total']){
                $cupon = base_url().'images/cupones/'.$cupon->Id.'.png';
            }else{
                $cupon = $this->cuentadigital($mail['sid'],$cuota3['titular'],$cuota3['total']);
                if($cupon && $mail['sid'] != 0){

                    $cupon_id = $this->pagos_model->generar_cupon($mail['sid'],$cuota3['total']);
                    $data = base64_decode($cupon);
                    $img = imagecreatefromstring($data);
                    if ($img !== false) {
                        //@header('Content-Type: image/png');
                        imagepng($img,'images/cupones/'.$cupon_id.'.png',0);
                        imagedestroy($img);
                        $cupon = base_url().'images/cupones/'.$cupon_id.'.png';
                    }else {
                        echo 'Ocurrió un error.';
                        $cupon = '';
                    }
                }
            }

            if($cupon){
                $cuerpo .= '<br><br><img src="'.$cupon.'">';
            }

            $cuerpo .= '';

            if($mail['deuda'] < 0){
                $total = ($mail['deuda']*-1);
                $cuerpo .= '<h3>Su deuda total con el Club es de: $ '.$total.'</h3>';
            }else{
                $total = ($mail['deuda']);
                $cuerpo .= '<h3>Usted posee un saldo a favor de: $ '.$total.'</h3>';                
            }

            //echo($cuerpo);
            //die;

            $email = array(
                    'email' => $mail['mail'],
                    'body' => $cuerpo
                );
            $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
            if(preg_match($regex, $mail['mail'])){
                $this->db->insert('facturacion_mails',$email);
            }
            /*$this->email->from('avisos@clubvillamitre.com','Club Villa Mitre');
            $this->email->to($mail['mail']);                 

            $this->email->subject('Resumen de Cuenta');                
            $this->email->message($cuerpo);  


            if(preg_match($regex, $mail['mail'])){
                $this->email->send();             
            }*/
			//mail

            $this->pagos_model->registrar_pago2($socio->Id,0);

		}
        $this->db->where('estado',1);
        $this->db->where('suspendido',1);
        $query = $this->db->get('socios');
        $socios_suspendidos = $query->result();
        foreach ($socios_suspendidos as $socio) {
            $mail = $this->socios_model->get_resumen_mail($socio->Id);
            $total = ($mail['deuda']*-1);

            $cuerpo = '<h3>Su deuda total con el Club es de: $ '.$total.'</h3>';

            //echo($cuerpo);
            //die;
            $this->email->from('avisos@clubvillamitre.com','Club Villa Mitre');
            $this->email->to($mail['mail']);                 

            $this->email->subject('Resumen de Cuenta');                
            $this->email->message($cuerpo);  

            $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';

            if(preg_match($regex, $mail['mail'])){
                //$this->email->send();
            }
        }

		
	}
	function pagos(){
		$this->load->model("pagos_model");
		if($this->pagos_model->check_cron_pagos()){exit('Esta tarea ya fue ejecutada hoy.');}	
		$ayer = date('Ymd',strtotime("-1 day"));
		$fecha = date('Y-m-d');
        //$ayer = '20151009';
        //$fecha = '2015-10-10';
		$pagos = $this->get_pagos($ayer);
        //var_dump($pagos);die;
		if($pagos){
			foreach ($pagos as $pago) {
				$data = $this->pagos_model->insert_pago($pago);
                $this->pagos_model->registrar_pago2($pago['sid'],$pago['monto']);
			}
            $this->pagos_model->insert_pagos_cron($fecha);
        }else{
			$this->pagos_model->insert_pagos_cron($fecha);
			//$this->pagos();
		}
	}

	function get_pagos($fecha)
    {           
        $this->config->load('cuentadigital');    
        $url = 'http://www.cuentadigital.com/exportacion.php?control='.$this->config->item('cd_control');;
        $url .= '&fecha='.$fecha;	    
	    if($a = file_get_contents($url)){
		   	$data = explode("\n",$a);
		   	$pago = array();
		   	foreach ($data as $d) {		   	  		 
				if($d){
			   		$entrantes = explode('/', $d);
			   		$dia = substr($entrantes[0], 0,2);
			   		$mes = substr($entrantes[0], 2,2);
			   		$anio = substr($entrantes[0], 4,4);
			   		$hora = substr($entrantes[1], 0,2);
			   		$min = substr($entrantes[1], 2,2);
			   		$pago[] = array(
			   				"fecha" => date('d-m-Y',strtotime($entrantes[0])),
			   				"hora" => $hora.':'.$min,
			   				"monto" => $entrantes[2],
			   				"sid" => $entrantes[3],
			   				"pid" => $entrantes[4]
			   			);
                    $p = array(
                            "fecha" => date('Y-m-d',strtotime($entrantes[0])),
                            "hora" => $hora.':'.$min,
                            "monto" => $entrantes[2],
                            "sid" => $entrantes[3],
                            "pid" => $entrantes[4]
                        );
                    $this->pagos_model->insert_cuentadigital($p);
			   	}
			}
		   	return $pago;
	    }else{
            if($a === FALSE) {
                mail("soporte@hostingbahia.com.ar","Fallo en Cron VM",date('Y-m-d H:i:s'));
                exit();
            }
	    	return false;
		}
    }

    function cuentadigital($sid, $nombre, $precio, $venc=null) 
    {
        $this->config->load("cuentadigital");
        $cuenta_id = $this->config->item('cd_id');
        $nombre = substr($nombre,0,40);
        $concepto  = $nombre.' ('.$sid.')';
        $repetir = true;
        $count = 0;
        $result = false;
        if(!$venc){
            $url = 'http://www.CuentaDigital.com/api.php?id='.$cuenta_id.'&codigo='.urlencode($sid).'&precio='.urlencode($precio).'&concepto='.urlencode($concepto).'&xml=1';
        }else{
            $url = 'http://www.CuentaDigital.com/api.php?id='.$cuenta_id.'&venc='.$venc.'&codigo='.urlencode($sid).'&precio='.urlencode($precio).'&concepto='.urlencode($concepto).'&xml=1';    
        }
        
        do{
            $count++;
            $a = file_get_contents($url);
            $a = trim($a);
            $xml = simplexml_load_string($a);
            // $xml = simplexml_import_dom($xml->REQUEST);
            if (($xml->ACTION) != 'INVOICE_GENERATED') {
                $repetir = true;
                echo('Error al generarlo: ');
                sleep(1);
                //echo '<a href="'.$url.'" target="_blank"><strong>Reenviar</strong></a>';
            } else {
                $repetir = false;
                //echo('<p>El cupon de aviso se ha enviado correctamente</p>');
                $result = $xml->INVOICE->BARCODEBASE64;
                //$result = $xml->INVOICE->INVOICEURL;

            }        
            if ($count > 5) { $repetir = false; };

        } while ( $repetir );    
            return $result;
    }

    public function intereses()
    {
        if(date('d') != 20){ die(); }
        $this->load->model('general_model');
        $config = $this->general_model->get_config();
        if($config->interes_mora > 0){
            $this->load->model("socios_model");            
            $this->load->model('pagos_model');
            $socios = $this->socios_model->get_socios_pagan();
            foreach ($socios as $socio) {
                $cuota = $this->pagos_model->get_monto_socio($socio->Id);
                $total = $this->pagos_model->get_socio_total($socio->Id);
                if($total*-1 > $cuota['total']){
                    $debe = $cuota['total'] * $config->interes_mora /100;
                    
                    $total = $total - $debe;
                    $facturacion = array(
                        'sid' => $socio->Id,
                        'descripcion'=>'Intereses por Mora',
                        'debe'=>$debe,
                        'haber'=>0,
                        'total'=>$total
                    );
                    $this->pagos_model->insert_facturacion($facturacion);

                    $pago = array(
                        'sid' => $socio->Id, 
                        'tutor_id' => $socio->Id,
                        'aid' => 0, 
                        'generadoel' => date('Y-m-d'),
                        'descripcion' => "Intereses por Mora",
                        'monto' => $debe,
                        'tipo' => 2,
                        );                    
                    $this->pagos_model->insert_pago_nuevo($pago);
                }
            }            
        }
    }

    public function facturacion_mails()
    {
        $this->load->database();
        error_log( date('d/m/Y G:i:s').": Buscando correos para enviar... \n", 3, "cron_envios.log");
        $this->db->where('estado',0);
        $query = $this->db->get('facturacion_mails');
        if($query->num_rows() == 0){ 
            error_log( date('d/m/Y G:i:s').": No se encontraron correos \n", 3, "cron_envios.log");
            return false;
        }else{
            error_log( date('d/m/Y G:i:s').": Se encontraron ".$query->num_rows()." correos. Enviando... \n", 3, "cron_envios.log");
            $this->load->library('email');
            foreach ($query->result() as $email) {
                $this->email->from('pagos@clubvillamitre.com','Club Villa Mitre');
                $this->email->to($email->email);                 

                $this->email->subject('Resumen de Cuenta');                
                $this->email->message($email->body);  

                if($this->email->send()){
                    error_log( date('d/m/Y G:i:s').": Enviado: ".$email->email." \n", 3, "cron_envios.log");
                    $this->db->where('Id',$email->Id);
                    $this->db->update('facturacion_mails',array('estado'=>1));
                }
                //if(preg_match($regex, $mail['mail'])){
                //}
                //mail
            }
            error_log( date('d/m/Y G:i:s').": Envio Finalizado \n", 3, "cron_envios.log");
            
        }
    }

    public function pagos_nuevos($value='')
    {
        return false; die;
        $this->load->database();
        $this->load->model('pagos_model');
        $this->db->where('estado',1);        
        $query = $this->db->get('socios');
        $socios = $query->result();
        foreach ($socios as $socio) {            
            $total = $this->pagos_model->get_socio_total($socio->Id);            
            $pago = array(
                'sid' => $socio->Id, 
                'tutor_id' => $sid,
                'aid' => 0, 
                'generadoel' => date('Y-m-d'),
                'descripcion' => "Deuda Anterior",
                'monto' => $total*-1,
                'tipo' => 1,
                );
            if($total*-1 < 0){
                $pago['descripcion'] = 'A favor';
                $pago['tipo'] = 5;
            }
            $this->pagos_model->insert_pago_nuevo($pago);
            var_dump($pago);
            echo '<hr>';
        }
    }

    public function correccion()
    {
        return false; die();
        $this->load->database();
        $this->load->model('pagos_model');
        $this->db->where('estado',1);
        $this->db->where('actual >',1);
        $query = $this->db->get('financiacion');
        $f = $query->result();
        foreach ($f as $ff) {
            $haber = ($ff->actual - 1) * ($ff->monto/$ff->cuotas);
            $total = $this->pagos_model->get_socio_total($ff->sid);
            $total = $total + $haber;
            $facturacion = array(
                'sid' => $ff->sid, 
                'descripcion' => 'Corrección de Financiación de Deuda', 
                'debe'=>0,
                'haber'=>$haber,
                'total'=>$total
                );

            $this->db->insert('facturacion',$facturacion);
            var_dump($facturacion);
            echo '<hr>';
        }
    }  

    public function control()
    {
        $this->load->model("pagos_model");
        $this->load->model("socios_model");
        $socios = $this->socios_model->listar(); //listamos todos los socios activos
        foreach ($socios as $socio) {    
            $total = $this->pagos_model->get_socio_total($socio['datos']->Id);
            $total2 = $this->pagos_model->get_socio_total2($socio['datos']->Id);
            if($total + $total2 != 0 && $total <= 0){
                echo $socio['datos']->Id.' | '.$total.' | '.$total2.'<br>';            
            }
        }
    }  
}