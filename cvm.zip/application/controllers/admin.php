<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();        
        $this->load->library(array('session','form_validation'));
        $this->load->helper(array('url','form','date'));       
        $this->load->model('login_model');
        $this->load->database('default');  
        $this->date_facturacion = 25;      
    }
    
    public function listado(){
        $this->load->model("socios_model");
        $this->load->model("pagos_model");
        $data['socios'] = $this->socios_model->listar();
        foreach ($data['socios'] as $socio){
            $actividades = '';
            foreach ($socio['actividades'] as $actividad) {
                if($actividad->estado != 0){
                    $actividades = $actividades.' '.$actividad->nombre;
                }
            }                                            
            $datos[] = [
            'id' => $socio['datos']->Id,
            'name' => $socio['datos']->nombre.' '.$socio['datos']->apellido,
            'dni'=>$socio['datos']->dni,
            'price' => $this->pagos_model->get_monto_socio($socio['datos']->Id)['total'],
            'actividades' => $actividades
            ];
        }
        
        $datos = json_encode($datos);
        echo $datos;
    }

    public function listado_act(){
        $this->load->model("actividades_model");
        $data['actividades'] = $this->actividades_model->get_actividades();
        foreach ($data['actividades'] as $actividad){                                           
            $datos[] = [
            'id' => $actividad->Id,
            'name' => $actividad->nombre,
            'price' => $actividad->precio            
            ];
        }
        $datos = json_encode($datos);
        echo $datos;
    }

	public function index()
	{
		if(!$this->session->userdata('is_logued_in')){			
			$data['token'] = $this->token();
            $data['baseurl'] = base_url();								
			$this->load->view('login-form',$data);				
		}else{
            redirect(base_url()."admin/socios");
		}
	}

    public function morosos(){
        $data['username'] = $this->session->userdata('username');
        $data['baseurl'] = base_url();
        $data['section'] = 'morosos';
        $this->load->view('admin',$data);    
    }

	public function login()
	{
		
        if($this->input->post('token') && $this->input->post('token') == $this->session->userdata('token'))        
        {
            $this->form_validation->set_rules('username', 'nombre de usuario', 'required|trim|min_length[2]|max_length[150]|xss_clean');
            $this->form_validation->set_rules('password', 'password', 'required|trim|min_length[5]|max_length[150]|xss_clean');
             //lanzamos mensajes de error si es que los hay          
            if($this->form_validation->run() == FALSE)
            {
            	$this->session->set_flashdata('usuario_incorrecto','Falta ingresar algún dato.');
                redirect(base_url().'admin');
            }else{
                $username = $this->input->post('username');
                $password = sha1($this->input->post('password'));
                $check_user = $this->login_model->login_user($username,$password);                
                if($check_user == TRUE)
                {
                    $data = array(
                    'is_logued_in'     =>         TRUE,
                    'id_usuario'     =>         $check_user->Id,
                    'rango'        =>        $check_user->rango,
                    'mail'        =>        $check_user->mail,
                    'username'         =>         $check_user->user
                    );                     
                    $this->session->set_userdata($data);
                    //$this->login_model->update_lCon();
                    redirect(base_url().'admin');
                }
            }
        }else{
            redirect(base_url().'admin');
        }
    }

	public function token()
    {
        $token = md5(uniqid(rand(),true));
        $this->session->set_userdata('token',$token);
        return $token;
    }
    public function img_token()
    {
        $token = md5(uniqid(rand(),true));
        $this->session->set_userdata('img_token',$token);
        return $token;
    }
      public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url().'admin');
    }    

    public function admins()
    {
        $this->load->model('admins_model');
        $this->login_model->update_lCon();
        $data['listaAdmin'] = $this->admins_model->get_admins();
        $data['username'] = $this->session->userdata('username');
        $data['baseurl'] = base_url();
        $data['section'] = 'admins';
        $this->load->view('admin',$data);
    }

    public function socios()
    {   
        switch ($this->uri->segment(3)) {
            /**

            **/

            case 'suspender':
                $this->load->model('socios_model');
                $this->socios_model->suspender($this->uri->segment(4));
                redirect(base_url().'admin/socios/resumen/'.$this->uri->segment(4));
                break;

            case 'desuspender':
                $this->load->model('socios_model');
                $this->socios_model->suspender($this->uri->segment(4),'no');
                redirect(base_url().'admin/socios/resumen/'.$this->uri->segment(4));
                break;
            case 'enviar_resumen':
                if(!$this->uri->segment(4)){return false;}
                $this->load->library('email');

                $config['charset'] = 'utf-8';                
                $config['mailtype'] = 'html';

                $this->email->initialize($config);

                $this->load->model('socios_model');
                $mail = $this->socios_model->get_resumen_mail($this->uri->segment(4));

                $cuota = $mail['resumen'];

                $cuerpo = '<h3><strong>Titular:</strong> '.$cuota['titular'].'</h3>';
                $cuerpo .= '<h5><strong>Categor&iacute;a:</strong> '.$cuota['categoria'].'</h5>';
                
                if($cuota['categoria'] == 'Grupo Familiar'){
               
                    $cuerpo .= '<h5><strong>Integrantes</strong></h5><ul>';
                    foreach ($cuota['familiares'] as $familiar) {          
                        $cuerpo .= '<li>'.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.'</li>';                    
                    }                    
                    $cuerpo .= '</ul>';            
                }
                
                $cuerpo .= '<table class="table table-hover" width="50%;" border="1">
                    <thead>
                        <tr>                        
                            <th align="left">Descripci&oacute;n</th>
                            <th align="left">Monto</th>                        
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Cuota Mensual '.$cuota['categoria'].'</td>
                            <td>$'.$cuota['cuota'].'</td>
                        </tr>';
                        foreach ($cuota['actividades']['actividad'] as $actividad) {
                        $cuerpo .= '<tr>
                            <td>Cuota Mensual '.$actividad->nombre.'</td>
                            <td>$'.$actividad->precio.'</td>
                        </tr>';                        
                        } 
                        if($cuota['familiares'] != 0){
                            foreach ($cuota['familiares'] as $familiar) {
                                foreach($familiar['actividades']['actividad'] as $actividad){                           
                                
                                $cuerpo .= '<tr>                    
                                    <td>Cuota Mensual '.$actividad->nombre.' ['.$familiar['datos']->nombre.' '.$familiar['datos']->apellido.' ]</td>
                                    <td>$ '.$actividad->precio.'</td>
                                </tr>';
                                }                                   
                            }
                        }
                        if($cuota['excedente'] >= 1){
                        
                        $cuerpo .='<tr>                    
                                    <td>Socio Extra (x'.$cuota['excedente'].')</td>
                                    <td>$'.$cuota['monto_excedente'].'</td>
                                </tr>';                        
                        }
                        if($cuota['financiacion']){
                            foreach ($cuota['financiacion'] as $plan) {                 
                        
                                $cuerpo .= '<tr>                    
                                    <td>Financiación de Deuda ('.$plan->detalle.')</td>
                                    <td>$'.round($plan->monto/$plan->cuotas,2).'</td>
                                </tr>';
                        
                            }
                        }
                        if($cuota['descuento'] != 0.00){                        
                            $cuerpo .= '<tr>                    
                                    <td>Descuento</td>
                                    <td>$'.$cuota['descuento'].'</td>
                                </tr>';                        
                        }
                        $cuerpo .= '
                    </tbody>
                    <tfoot>
                        <tr>                        
                            <th>Total</th>
                            <th>$'.$cuota['total'].'</th>                        
                        </tr>
                    </tfoot>
                </table>';
                
                // cupon
                $this->load->model('pagos_model');
                $cupon = $this->pagos_model->get_cupon($mail['sid']);
                if($cupon->monto == $cuota['total']){
                    $cupon = base_url().'images/cupones/'.$cupon->Id.'.png';
                }else{
                    $cupon = $this->cuentadigital($mail['sid'],$cuota['titular'],$cuota['total']);
                    if($cupon && $mail['sid'] != 0){

                        $cupon_id = $this->pagos_model->generar_cupon($mail['sid'],$cuota['total']);
                        $data = base64_decode($cupon);
                        $img = imagecreatefromstring($data);
                        if ($img !== false) {
                            //@header('Content-Type: image/png');
                            imagepng($img,'images/cupones/'.$cupon_id.'.png',0);
                            imagedestroy($img);
                            $cupon = base_url().'images/cupones/'.$cupon_id.'.png';
                        }else {
                            echo 'Ocurrió un error.';
                            $cupon = '';
                        }

                    }
                }

                if($cupon){
                    $cuerpo .= '<br><br><img src="'.$cupon.'">';
                }


                $cuerpo .= '';

                $total = ($mail['deuda']*-1);

                $cuerpo .= '<h3>Su deuda total con el Club es de: $ '.$total.'</h3>';

                //echo($cuerpo);
                //die;
                $this->email->from('pagos@clubvillamitre.com');
                $this->email->to($mail['mail']);                 

                $this->email->subject('Resumen de Cuenta');                
                $this->email->message($cuerpo);  

                $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';

                if(preg_match($regex, $mail['mail'])){
                    $this->email->send();
                    $data['enviado'] = 'ok';
                }else{
                    $data['enviado'] = 'no_mail';
                }
                    $data['baseurl'] = base_url();
                    $data['section'] = 'socios-resumen_enviado';
                    $this->load->view('admin',$data);                
                break;
            /**

            **/
            case 'buscar':
                if($_GET['dni']){
                    $this->load->model('socios_model');
                    $socio = $this->socios_model->get_socio_by(array('dni'=>$_GET['dni']));
                    if($socio){
                        redirect(base_url().'admin/socios/resumen/'.$socio[0]->Id);
                    }else{
                        redirect(base_url().'admin/socios');   
                    }
                }else{
                    redirect(base_url().'admin/socios');
                }
                break;
            case 'agregar':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['action'] = 'nuevo';
                $data['section'] = 'socios-nuevo';
                $data['socio'] = '';
                $this->load->model("general_model");
                $data['categorias'] = $this->general_model->get_cats();
                
                $this->load->model("socios_model");
                $data['socios'] = $this->socios_model->get_socios();                
                $this->load->view('admin',$data);
                break;

            case 'nuevo':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $datos = array();
                foreach($_POST as $key => $val)  
                {  
                    $datos[$key] = $this->input->post($key);  
                }     
                if($datos['socio_n'] >= 28852){
                    $datos['socio_n'] = '';
                    $error = "?e=socio_n";
                }  
                $datos['r1'] = $datos['r1-id'];
                $datos['r2'] = $datos['r2-id'];
                $datos['tutor'] = $datos['r3-id'];
                unset($datos['r1-id']);
                unset($datos['r2-id']);
                unset($datos['r3-id']);
                unset($datos['r3']);
                if(isset($datos['deuda'])){                    
                    $deuda = $datos['deuda'];
                    unset($datos['deuda']);
                }
                $this->load->model("socios_model");
                
                if($prev_user = $this->socios_model->checkDNI($datos['dni'])){
                    //el dni esta repetido, incluimos la vista de listado con el usuario coincidente
                    $data['username'] = $this->session->userdata('username');               
                    $data['prev_user'] = $prev_user;
                    $data['baseurl'] = base_url();
                    $data['section'] = 'socio-dni-repetido';                    
                    $this->load->view('admin',$data);
                }else{
                    //llamamos al modelo en insertamos los datos
                    //$fecha = explode('-',$datos['nacimiento']);
                    //$datos['nacimiento'] = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
                    $uid = $this->socios_model->register($datos);
                    if(file_exists("images/temp/".$this->session->userdata('img_token').".jpg")){                    
                        rename("images/temp/".$this->session->userdata('img_token').".jpg","images/socios/".$uid.".jpg");
                    }
                    //guardamos la variable con la data de la foto en una imagen 
                    if($deuda){
                        //llamamos a la vista de financiar deuda para este usuario con el monto ingresado
                        $this->socios_model->insert_deuda($uid,$deuda);
                    }

                    if(date('d') < $this->date_facturacion){ //si la fecha es anterior a la definida                        
                        if($datos['tutor'] == 0){ // y no es un integrante de grupo familiar                        
                            $this->load->model('pagos_model');
                            $cuota = $this->pagos_model->get_monto_socio($uid);

                            $descripcion = '<strong>Categoría:</strong> '.$cuota['categoria'];
                            if($cuota['categoria'] == 'Grupo Familiar'){
                                $descripcion .= '<br><strong>Integrantes:</strong> ';
                                foreach ($cuota['familiares'] as $familiar) {
                                    $descripcion .= "<li>".$familiar['datos']->nombre." ".$familiar['datos']->apellido."</li>";
                                }
                            }
                            $descripcion .= '<br><strong>Detalles</strong>:<br>';
                            $descripcion .= 'Cuota Mensual '.$cuota['categoria'].' -';
                            if($cuota['descuento'] > 0.00){
                                $descripcion .= "$ ".$cuota['cuota_neta']." &nbsp;<label class='label label-info'>".$cuota['descuento']."% BECADO</label>";
                            }
                            $descripcion .= '$ '.$cuota['cuota'].'<br>';

                            $pago = array(
                                'sid' => $uid, 
                                'tutor_id' => $uid,
                                'aid' => 0, 
                                'generadoel' => date('Y-m-d'),
                                'descripcion' => $descripcion,
                                'monto' => $cuota['cuota'],                
                                'tipo' => 1,                
                                );
                            $this->pagos_model->insert_pago_nuevo($pago);

                            $facturacion = array(
                                'sid' => $uid, 
                                'descripcion'=>$descripcion,
                                'debe' => $cuota['cuota'],
                                'haber' => 0,
                                'total' => $cuota['cuota']*-1
                                );
                            $this->pagos_model->insert_facturacion($facturacion);
                        }
                    }
                    redirect(base_url()."admin/socios/registrado/".$uid);
                    
                }
                break;

            case 'nuevo-tutor':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                //if(!$this->session->userdata('username')){ redirect(base_url()."admin"); }
                $tutor['nombre'] = $this->input->get("tutor-nombre");
                $tutor['apellido'] = $this->input->get("tutor-apellido");
                $tutor['dni'] = $this->input->get("tutor-dni");
                $tutor['telefono'] = $this->input->get("tutor-telefono");
                $tutor['mail'] = $this->input->get("tutor-mail");
                $this->load->model("socios_model");
                //echo $tutor['dni']; die;
                if(!$tutor['dni'] || $prev_user = $this->socios_model->checkDNI($tutor['dni'])){
                    //el dni esta repetido, enviamos DNI para que jquery se encargue
                    echo "DNI";
                }else{                    
                    $uid = $this->socios_model->register($tutor);
                    $data = array("Id"=>$uid,"nombre"=>$tutor['nombre'],"apellido"=>$tutor['apellido'],"dni"=>$tutor['dni']);
                    echo (json_encode($data));
                }
                break;

            case 'agregar_imagen':
                $token = $this->img_token();
                if(move_uploaded_file($_FILES['webcam']['tmp_name'], 'images/temp/'.$token.'.jpg')){
                    echo $token;
                }
                break;

            case 'subir_imagen':

                $token = $this->img_token();
                $this->load->library('UploadHandler');
                die;
                if(move_uploaded_file($_FILES['webcam']['tmp_name'], 'images/temp/'.$token.'.jpg')){
                    echo $token;
                }
                break;

            case 'registrado':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['uid'] = $this->uri->segment(4);
                $data['section'] = 'socios-registrado';
                $this->load->view('admin',$data);
                break;

            case 'editar':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();                
                $data['section'] = 'socios-editar';
                $this->load->model("general_model");
                $data['categorias'] = $this->general_model->get_cats();
               // $data['localidad'] = $this->general_model->get_ciudades();
                $this->load->model("socios_model");
                $data['socio'] = $this->socios_model->get_socio($this->uri->segment(4));
                if($data['socio']){                   
                    $data['contacto1'] = $this->socios_model->get_socio($data['socio']->r1);
                    $data['contacto2'] = $this->socios_model->get_socio($data['socio']->r2);
                    $data['tutor'] = $this->socios_model->get_socio($data['socio']->tutor);
                    if(!$data['socio']->socio_n){
                        $data['socio']->socio_n = $this->uri->segment(4);
                    }
                }else{
                    
                }
                
                $this->load->view('admin',$data);
                break;

            case 'guardar':
                $id = $this->uri->segment(4); // id del socio                
                foreach($_POST as $key => $val)  
                {  
                    $datos[$key] = $this->input->post($key);  
                }
                $this->load->model("socios_model");
                $socio_n = $this->socios_model->check_u_n($datos['socio_n']);                
                if($datos['socio_n'] == 0){
                    $datos['socio_n'] = '';
                }
                $socio_n = false;
                if(($datos['socio_n'] >= 28852 && $datos['socio_n'] != $id )|| $socio_n == true){
                    $datos['socio_n'] = '';
                    $error = "?e=socio_n";
                }
                $datos['r1'] = $datos['r1-id'];
                $datos['r2'] = $datos['r2-id'];
                $datos['tutor'] = $datos['r3-id'];
                unset($datos['r1-id']);
                unset($datos['r2-id']);
                unset($datos['r3-id']);
                unset($datos['r3']);
                //$fecha = explode('-',$datos['nacimiento']);
                //$datos['nacimiento'] = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
                
                if($prev_user = $this->socios_model->checkDNI($datos['dni'],$id)){
                    //el dni esta repetido, incluimos la vista de listado con el usuario coincidente                
                    $data['username'] = $this->session->userdata('username');               
                    $data['prev_user'] = $prev_user;
                    $data['baseurl'] = base_url();
                    $data['section'] = 'socio-dni-repetido';                    
                    $this->load->view('admin',$data);
                }else{                    
                    $token = $this->session->userdata('img_token');
                    if(file_exists("images/temp/".$token.".jpg")){
                      
                        rename("images/temp/".$this->session->userdata('img_token').".jpg","images/socios/".$id.".jpg");
                    }
                    $this->socios_model->update_socio($id,$datos);
                    if(!isset($error)){
                        $error = '';
                    }               
                    redirect(base_url()."admin/socios/registrado/".$id.$error);
                }
                
                break;
                
            case 'borrar':                
                $data['baseurl'] = base_url();                
                $this->load->model("socios_model");
                $this->socios_model->borrar_socio($this->uri->segment(4));
                redirect(base_url()."admin/socios");
                break;
            case 'resumen':
                $this->load->model('socios_model');
                $this->load->model('pagos_model');
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['socio'] = $this->socios_model->get_socio($this->uri->segment(4));
                $data['facturacion'] = $this->pagos_model->get_facturacion($this->uri->segment(4));                
                $data['cuota'] = $this->pagos_model->get_monto_socio($this->uri->segment(4));
                $data['section'] = 'socios-resumen';          
                $this->load->view('admin',$data); 
                break;
            case 'resumen2':
                $this->load->model('socios_model');
                $this->load->model('pagos_model');
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['socio'] = $this->socios_model->get_socio($this->uri->segment(4));
                $data['facturacion'] = $this->pagos_model->get_facturacion($this->uri->segment(4));
                $data['cuota'] = $this->pagos_model->get_monto_socio($this->uri->segment(4))['total'];
                $data['section'] = 'socios-resumen2';          
                $this->load->view('socios-resumen2',$data); 
                break;
             case 'resumen-deuda':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['deuda'] = 'only';
                $data['section'] = 'socios-resumen';                
                $this->load->view('admin',$data); 
                break;

             case 'resumen-sindeuda':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['deuda'] = 'no';
                $data['section'] = 'socios-resumen';
                $this->load->view('admin',$data);
                break;

            case 'categorias':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'socios-categorias';
                $this->load->view('admin',$data);
                break;

            default:
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'socios';
                $this->load->model("socios_model");
                $data['socios'] = $this->socios_model->listar();
                $this->load->view('admin',$data);
                break;
        }
    }
    
    public function actividades()
    {
        switch ($this->uri->segment(3)) {
            case 'baja':
                $sid = $this->uri->segment(4);
                $aid = $this->uri->segment(5);
                $this->load->model("actividades_model");
                $act = $this->actividades_model->act_baja($sid, $aid);
                echo $act;
                break;

            case 'alta':
                $data['sid'] = $this->uri->segment(4);
                $data['aid'] = $this->uri->segment(5);
                $this->load->model("actividades_model");
                $this->load->model("socios_model");
                $act = $this->actividades_model->act_alta($data);
                $facturar = $this->uri->segment(6);
                if(date('d') < $this->date_facturacion && $facturar == 'true'){ //si la fecha es anterior a la definida                        

                    $actividad = $this->actividades_model->get_actividad($data['aid']);
                    $this->load->model('pagos_model');                

                    $descripcion = 'Cuota Mensual '.$actividad->nombre.' - $ '.$actividad->precio;                                

                    $socio = $this->socios_model->get_socio($data['sid']);
                    if($socio->tutor != 0){
                        $tutor_id = $socio->tutor;
                    }else{
                        $tutor_id = $data['sid'];
                    }
                    $pago = array(
                        'sid' => $data['sid'], 
                        'tutor_id' => $tutor_id,
                        'aid' => $data['aid'] , 
                        'generadoel' => date('Y-m-d'),
                        'descripcion' => $descripcion,
                        'monto' => $actividad->precio,                
                        'tipo' => 4,                
                        );
                    $this->pagos_model->insert_pago_nuevo($pago);

                    $total = $this->pagos_model->get_socio_total($data['sid']); 

                    $facturacion = array(
                        'sid' => $tutor_id, 
                        'descripcion'=>$descripcion,
                        'debe' => $actividad->precio,
                        'haber' => 0,
                        'total' => $total - $actividad->precio
                        );
                    $this->pagos_model->insert_facturacion($facturacion);
                }
                echo $act;
                break;   

            case 'get':
                $data['sid'] = $this->uri->segment(4);
                $data['baseurl'] = base_url();
                $this->load->model('actividades_model');
                $data['actividades'] = $this->actividades_model->get_actividades();
                $data['actividades_asoc'] = $this->actividades_model->get_act_asoc($data['sid']);                
                $this->load->view('actividades-lista',$data);
                break;

            case 'asociar':
                $data['sid'] = $this->uri->segment(4);
                $this->load->model('socios_model');
                $data['socio'] = $this->socios_model->get_socio($data['sid']);
                $data['section'] = 'actividades-asociar';
                $data['baseurl'] = base_url();
                $this->load->view("admin",$data);            
                break;
            case 'agregar':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'actividades-agregar';
                $this->load->model("actividades_model");
                $data['profesores'] = $this->actividades_model->get_profesores();
                $data['lugares'] = $this->actividades_model->get_lugares();
                $this->load->view('admin',$data); 
                break;
            
            case 'nueva':
                foreach($_POST as $key => $val)  
                    {  
                        $datos[$key] = $this->input->post($key);  
                    }
                if($datos['nombre']){
                    $this->load->model('actividades_model');
                    $aid = $this->actividades_model->reg_actividad($datos);
                    redirect(base_url()."admin/actividades/guardada/".$aid);
                }else{
                    redirect(base_url()."admin/actividades"); 
                }
                break;

            case 'guardada':
                $data['aid'] = $this->uri->segment(4);
                $data['section'] = 'actividades-guardada';
                $data['baseurl'] = base_url();
                $this->load->view("admin",$data);
                break;
            case 'editar':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $this->load->model('actividades_model');
                $data['actividad'] = $this->actividades_model->get_actividad($this->uri->segment(4));
                $data['profesores'] = $this->actividades_model->get_profesores();
                $data['lugares'] = $this->actividades_model->get_lugares();                
                $data['section'] = 'actividades-editar';
                $this->load->view('admin',$data); 
                break;

            case 'guardar':
                foreach($_POST as $key => $val)  
                {  
                    $datos[$key] = $this->input->post($key);  
                }
                if($datos['nombre']){
                    $this->load->model("actividades_model");
                    $this->actividades_model->update_actividad($datos,$this->uri->segment(4));
                    redirect(base_url()."admin/actividades/guardada/".$this->uri->segment(4));
                }
                break;
            case 'eliminar':
                $this->load->model("actividades_model");
                $this->actividades_model->del_actividad($this->uri->segment(4));
                redirect(base_url()."admin/actividades");
                break;
            case 'profesores':
                if($this->uri->segment(4) == 'nuevo'){
                    foreach($_POST as $key => $val)  
                    {  
                        $datos[$key] = $this->input->post($key);  
                    }
                    if($datos['nombre'] && $datos['apellido']){
                        $this->load->model("actividades_model");
                        $pid = $this->actividades_model->reg_profesor($datos);
                        redirect(base_url()."admin/actividades/profesores/guardado/".$pid);
                    }else{
                        redirect(base_url()."admin/actividades/profesores");
                    }
                }else if($this->uri->segment(4) == 'guardar'){
                    foreach($_POST as $key => $val)  
                    {  
                        $datos[$key] = $this->input->post($key);  
                    }
                    if($datos['nombre'] && $datos['apellido']){
                        $this->load->model("actividades_model");
                        $this->actividades_model->update_profesor($datos,$this->uri->segment(5));
                        redirect(base_url()."admin/actividades/profesores/guardado/".$this->uri->segment(5));
                    }
                }else if($this->uri->segment(4) == 'editar'){
                    $data['baseurl'] = base_url();
                    $data['section'] = 'profesores-editar';
                    $this->load->model('actividades_model');
                    $data['profesor'] = $this->actividades_model->get_profesor($this->uri->segment(5));
                    $this->load->view('admin',$data);  
                }else if($this->uri->segment(4) == 'guardado'){
                    $data['pid'] = $this->uri->segment(5);
                    $data['section'] = 'profesores-guardado';
                    $data['baseurl'] = base_url();
                    $this->load->view("admin",$data);
                }else if($this->uri->segment(4) == 'eliminar'){
                    $this->load->model("actividades_model");
                    $this->actividades_model->del_profesor($this->uri->segment(5));
                    redirect(base_url()."admin/actividades/profesores");
                }else{
                    $data['username'] = $this->session->userdata('username');
                    $data['baseurl'] = base_url();
                    $data['section'] = 'actividades-profesores';
                    $this->load->model('actividades_model');
                    $data['profesores'] = $this->actividades_model->get_profesores();
                    $this->load->view('admin',$data);
                } 
                break;

            case 'lugares':
                if($this->uri->segment(4) == 'nuevo'){
                    foreach($_POST as $key => $val)  
                    {  
                        $datos[$key] = $this->input->post($key);  
                    }
                    if($datos['nombre']){
                        $this->load->model("actividades_model");
                        $pid = $this->actividades_model->reg_lugar($datos);
                        redirect(base_url()."admin/actividades/lugares/guardado/".$pid);
                    }else{
                        redirect(base_url()."admin/actividades/lugares");
                    }
                }else if($this->uri->segment(4) == 'guardar'){
                    foreach($_POST as $key => $val)  
                    {  
                        $datos[$key] = $this->input->post($key);  
                    }
                    if($datos['nombre']){
                        $this->load->model("actividades_model");
                        $this->actividades_model->update_lugar($datos,$this->uri->segment(5));
                        redirect(base_url()."admin/actividades/lugares/guardado/".$this->uri->segment(5));
                    }
                }else if($this->uri->segment(4) == 'editar'){
                    $data['baseurl'] = base_url();
                    $data['section'] = 'lugares-editar';
                    $this->load->model('actividades_model');
                    $data['lugar'] = $this->actividades_model->get_lugar($this->uri->segment(5));
                    $this->load->view('admin',$data);  
                }else if($this->uri->segment(4) == 'guardado'){
                    $data['pid'] = $this->uri->segment(5);
                    $data['section'] = 'lugares-guardado';
                    $data['baseurl'] = base_url();
                    $this->load->view("admin",$data);
                }else if($this->uri->segment(4) == 'eliminar'){
                    $this->load->model("actividades_model");
                    $this->actividades_model->del_lugar($this->uri->segment(5));
                    redirect(base_url()."admin/actividades/lugares");
                }else{
                    $data['username'] = $this->session->userdata('username');
                    $data['baseurl'] = base_url();
                    $data['section'] = 'actividades-lugares';
                    $this->load->model('actividades_model');
                    $data['lugares'] = $this->actividades_model->get_lugares();
                    $this->load->view('admin',$data);
                } 
                break;

            case 'becar':
                $id = $this->input->post('id');
                $beca = $this->input->post('beca');
                $this->load->model('actividades_model');
                $this->actividades_model->becar($id,$beca);
                break;


            default:
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'actividades';
                $this->load->model('actividades_model');
                $data['actividades'] = $this->actividades_model->get_actividades();
                $this->load->view('admin',$data);
                break;
        }            
    }    

    public function pagos()
    {
        switch ($this->uri->segment(3)) {
            case 'registrar':
                switch($this->uri->segment(4)){
                    case 'do':
                        $this->load->model("pagos_model");
                        $data = $this->pagos_model->registrar_pago($_POST['tipo'],$_POST['sid'],$_POST['monto'],$_POST['des'],$_POST['actividad']);
                        echo $data;
                    break;
                    case 'get':
                        $this->load->model('socios_model');
                        $this->load->model('pagos_model');
                        $this->load->model('actividades_model');
                        $data['username'] = $this->session->userdata('username');
                        $data['baseurl'] = base_url();                
                        $data['socio'] = $this->socios_model->get_socio($this->uri->segment(5));
                        $data['facturacion'] = $this->pagos_model->get_facturacion($this->uri->segment(5));
                        $data['actividades'] = $this->actividades_model->get_actividades();
                        $this->load->view('pagos-registrar-get',$data);
                    break;

                    default:
                        $data['username'] = $this->session->userdata('username');
                        $data['baseurl'] = base_url();
                        $data['section'] = 'pagos-registrar';
                        $data['sid'] = $this->uri->segment(4);
                        $this->load->model('socios_model');
                            if($data['sid']){
                                $this->load->model('pagos_model');
                                $data['cuota'] = $this->pagos_model->get_monto_socio($data['sid']);
                            }                        
                        $data['socio'] = $this->socios_model->get_socio($data['sid']);
                        $this->load->view('admin',$data);
                    break;
                }
                break;
            case 'facturacion':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'pagos-facturacion';
                $this->load->view('admin',$data);
                break;

            case 'cupon':
                switch($this->uri->segment(4)){
                    case 'imprimir':
                        $this->load->model('pagos_model');
                        $data['baseurl'] = base_url();                        
                        $data['cupon'] = $this->pagos_model->get_cupon_by_id($this->uri->segment(5));                        
                        $this->load->view('cupon-imprimir',$data);
                        break;
                    case 'get':
                        $data['sid'] = $this->uri->segment(5);
                        $this->load->model('pagos_model');
                        $data['baseurl'] = base_url();
                        $data['cupon'] = $this->pagos_model->get_cupon($data['sid']);
                        $data['cuota'] = $this->pagos_model->get_monto_socio($data['sid']);
                        $this->load->view('pagos-cupon-get',$data);
                        break;
                    case 'generar':
                        if($_POST['id'] && $_POST['monto']){
                            $this->load->model('socios_model');
                            $socio = $this->socios_model->get_socio($_POST['id']);
                            $cupon = $this->cuentadigital($_POST['id'],$socio->nombre.' '.$socio->apellido,$_POST['monto']);
                            if($cupon){                                    
                                $this->load->model('pagos_model');
                                $cupon_id = $this->pagos_model->generar_cupon($_POST['id'],$_POST['monto']);
                                $data = base64_decode($cupon);
                                $img = imagecreatefromstring($data);
                                    if ($img !== false) {
                                        @header('Content-Type: image/png');
                                        imagepng($img,'images/cupones/'.$cupon_id.'.png',0);
                                        imagedestroy($img);
                                    }
                                    else {
                                        echo 'Ocurrió un error.';
                                    }
                                echo $_POST['id'];
                            }
                        }
                        break;
                    default:
                        $data['username'] = $this->session->userdata('username');
                        $data['baseurl'] = base_url();
                        $data['section'] = 'pagos-cupon';
                        $data['sid'] = $this->uri->segment(4);
                        $this->load->model('socios_model');
                        if($data['sid']){
                            $this->load->model('pagos_model');
                            $data['cuota'] = $this->pagos_model->get_monto_socio($data['sid']);
                        }                        
                        $data['socio'] = $this->socios_model->get_socio($data['sid']);
                        $this->load->view('admin',$data);
                        break;
                    } 
                    break;
            
            case 'deuda':
                switch ($this->uri->segment(4)) {
                    case 'get':
                        $this->load->model('pagos_model'); 
                        $data['deuda'] = $this->pagos_model->get_deuda($this->uri->segment(5));
                        $data['planes'] = $this->pagos_model->get_planes($this->uri->segment(5));
                        $this->load->view('pagos-deuda-get',$data);
                        break;
                    
                    case 'financiar':
                        $socio = $this->input->post('sid');
                        $monto = $this->input->post('monto');
                        $cuotas = $this->input->post('cuotas');
                        $detalle = $this->input->post('detalle');
                        if($socio && $monto && $cuotas){
                            $this->load->model('pagos_model');
                            $this->pagos_model->financiar_deuda($socio,$monto,$cuotas,$detalle);
                        }
                        break;

                    case 'cancelar_plan':
                        $id = $this->input->post('id');
                        if($id){
                            $this->load->model('pagos_model');
                            $this->pagos_model->cancelar_plan($id);
                        }
                        break;

                    default:
                        $data['username'] = $this->session->userdata('username');
                        $data['baseurl'] = base_url();
                        $this->load->model('socios_model');
                        $data['sid'] = $this->uri->segment(4);
                        $data['socio'] = $this->socios_model->get_socio($data['sid']);
                        $data['section'] = 'pagos-deuda';                
                        $this->load->view('admin',$data);                        
                        break;
                }
                break;
            case 'deuda-socio':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'pagos-deuda';
                $data['socio'] = 'socio';
                $this->load->view('admin',$data);
                break;

            case 'editar':
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'pagos-editar';
                $data['socio'] = 'socio';
                $data['sid'] = $this->uri->segment(4);
                $this->load->model('socios_model');
                $data['socio'] = $this->socios_model->get_socio($data['sid']);
                $this->load->view('admin',$data);
                break;

            case 'get_pagos':
                $socio_id = $this->uri->segment(4);
                $this->load->model('pagos_model');
                $data['pagos'] = $this->pagos_model->get_pagos_edit($socio_id);
                $this->load->view('pagos-get-edit', $data, FALSE);
                break;

            case 'eliminar':
                $id = $this->uri->segment(4);
                $this->load->model('pagos_model');
                $socio_id = $this->pagos_model->eliminar_pago($id);
                redirect(base_url().'admin/pagos/editar/'.$socio_id,'refresh');
                break;

            default:                            
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();
                $data['section'] = 'listado_imprimir';
                $this->load->model('pagos_model');
                $meses = $this->uri->segment(3);
                if(!$meses){ $meses = 6; }
                $actividad = $this->uri->segment(4) ?: null;                            
                $data['morosos'] = $this->pagos_model->get_morosos($meses, $actividad);
                $this->load->model('actividades_model');
                $data['meses'] = $meses;
                $data['actividad_sel'] = $actividad;
                $data['actividades'] = $this->actividades_model->get_actividades();
                $this->load->view('admin',$data);
                break;
        }
     
    }

    public function estadisticas()
    {
        $this->load->model('estadisticas_model');
        if($this->uri->segment(3) == 'facturacion')
        {
            $data['username'] = $this->session->userdata('username');
            $data['baseurl'] = base_url();
            $data['facturacion_mensual'] = $this->estadisticas_model->facturacion_mensual();
            $data['facturacion_anual'] = $this->estadisticas_model->facturacion_anual();
            $data['section'] = 'estadisticas-facturacion';
            $this->load->view('admin',$data);
            
        }else{
            $data['username'] = $this->session->userdata('username');
            $data['baseurl'] = base_url();
            $data['actividades_mensual'] = $this->estadisticas_model->actividades_mensual();
            $data['actividades_anual'] = $this->estadisticas_model->actividades_anual();
            $data['section'] = 'estadisticas-actividades';
            $this->load->view('admin',$data);
        }      
    }
    public function configuracion()
    {
        switch($this->uri->segment(3)){
            case 'categorias':
                $precios = $this->input->post('precios');
                $fam = $this->input->post('fam');
                $this->load->model('general_model');
                $this->general_model->save_cat_config($precios,$fam);
                break;

            case 'guardar':
                $this->load->model('general_model');
                $interes_mora = $this->input->post('interes_mora');
                $config = array('interes_mora' => $interes_mora );
                $this->general_model->update_config($config);
                redirect(base_url().'admin/configuracion/guardada');
                break;

            default:
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();        
                $data['section'] = 'configuracion';
                $this->load->model("general_model");
                $data['config'] = $this->general_model->get_config();
                $data['cats'] = $this->general_model->get_cats();
                $this->load->view('admin',$data);
                break;
        }
    }
    public function soporte()
    {
        if($this->uri->segment(3) == 'enviar' && $_POST['consulta']){
            $this->load->library('email');

            $this->email->from($this->session->userdata('mail'), $this->session->userdata('username'));
            $this->email->to('sistemas@nixel.com.ar');             

            $this->email->subject('Solicitud de Soporte: CVM');
            $this->email->message($_POST['consulta']);  

            $this->email->send();
        
            $data['username'] = $this->session->userdata('username');
            $data['baseurl'] = base_url();        
            $data['section'] = 'soporte-enviado';
            $this->load->view('admin',$data);
        }else{
            $data['username'] = $this->session->userdata('username');
            $data['baseurl'] = base_url();        
            $data['section'] = 'soporte';
            $this->load->view('admin',$data);
        }
    }
    function mostrar_fecha($fecha)
    {
        $fecha = explode('-', $fecha);
        return $fecha[2].'/'.$fecha[1].'/'.$fecha[0];
    }

    function cuentadigital($sid, $nombre, $precio, $venc=null) 
    {
        $this->config->load("cuentadigital");
        $cuenta_id = $this->config->item('cd_id');
        $nombre = substr($nombre,0,40);
        $concepto  = $nombre.' ('.$sid.')';
        $repetir = true;
        $count = 0;
        $result = false;
        if(!$venc){
            $url = 'http://www.CuentaDigital.com/api.php?id='.$cuenta_id.'&codigo='.urlencode($sid).'&precio='.urlencode($precio).'&concepto='.urlencode($concepto).'&xml=1';
        }else{
            $url = 'http://www.CuentaDigital.com/api.php?id='.$cuenta_id.'&venc='.$venc.'&codigo='.urlencode($sid).'&precio='.urlencode($precio).'&concepto='.urlencode($concepto).'&xml=1';    
        }
        
        do{
            $count++;
            $a = file_get_contents($url);
            $a = trim($a);
            $xml = simplexml_load_string($a);
            // $xml = simplexml_import_dom($xml->REQUEST);
            if (($xml->ACTION) != 'INVOICE_GENERATED') {
                $repetir = true;
                echo('Error al generarlo: ');
                sleep(1);
                //echo '<a href="'.$url.'" target="_blank"><strong>Reenviar</strong></a>';
            } else {
                $repetir = false;
                //echo('<p>El cupon de aviso se ha enviado correctamente</p>');
                $result = $xml->INVOICE->BARCODEBASE64;
                //$result = $xml->INVOICE->INVOICEURL;

            }        
            if ($count > 5) { $repetir = false; };

        } while ( $repetir );    
            return $result;
    }

    public function envios($action='',$id='')
    {
        switch ($action) {
            case 'enviar':
                $this->load->model('general_model');
                $data['envio'] = $this->general_model->get_envio($id);
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();        
                $data['section'] = 'envios-enviar';
                $this->load->view('admin',$data);
                break;

            case 'send':                
                $this->load->model('general_model');
                $envio_info = $this->general_model->get_envio($id);
                $envio = $this->general_model->get_envio_data($id);
                if($envio){
                    $this->load->library('email');                                        
                    $this->email->from('avisos@clubvillamitre.com', 'Club Villa Mitre');
                    $this->email->to($envio->email);
                    $this->email->subject($envio_info->titulo);
                    $this->email->message($envio_info->body);
                    $this->email->send();
                    
                    //echo $this->email->print_debugger();

                    $this->general_model->enviado($envio->Id);
                    $data['estado'] = date('H:i:s').' - '.$envio->email.' <i class="fa fa-check" style="color:#1e9603"></i>';
                    $data['enviados'] = $this->general_model->get_enviados($id);
                    $data = json_encode($data);
                    echo $data;
                }else{
                    echo 'end';
                }
                break;

            case 'nuevo':
                $this->load->model('general_model');
                $this->load->model('actividades_model');
                $data['categorias'] = $this->general_model->get_cats();
                $data['actividades'] = $this->actividades_model->get_actividades();
                $data['profesores'] = $this->actividades_model->get_profesores();
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();        
                $data['section'] = 'envios-nuevo';
                $this->load->view('admin',$data);
                break;

            case 'guardar':
                $this->load->model('general_model');
                $envio = array('body' => $this->input->post('text') );
                $this->general_model->update_envio($id,$envio);
                break;

            case 'agregar':
                $titulo = $this->input->post('titulo');
                $grupo = $this->input->post('grupo');
                $data = $this->input->post('data');
                $envio = array(
                    'titulo' => $titulo, 
                    'grupo' => $grupo, 
                    'data' => json_encode($data),
                    );
                $this->load->model('general_model');
                $id = $this->general_model->insert_envio($envio);
                $socios = $this->general_model->get_socios_by($grupo,$data);
                $this->load->helper('email');
                if($socios){
                    $emails = array();
                    foreach ($socios as $socio) {
                        if (valid_email(@$socio->mail)){
                            $emails[] = $socio->mail;
                        }                        
                    }
                    $emails = array_unique($emails);
                    foreach ($emails as $email) {
                        $envio_data = array(
                            'eid' => $id, 
                            'email' => $email
                            );
                        $this->general_model->insert_envios_data($envio_data);
                    }
                    if(count($emails) <= 0){
                        echo 'no_mails';
                    }else{
                        $data['id'] = $id;
                        $data['body'] = false;
                        $data['titulo'] = $titulo;
                        $data['total'] = count($emails);
                        $this->load->view("envios-text",$data);                        
                    }
                }else{
                    echo 'no_mails';
                }
                break;

            case 'eliminar':
                $this->load->model('general_model');
                $envio = array('estado' => 0);
                $this->general_model->update_envio($id,$envio);
                redirect(base_url().'admin/envios');
                break;

            case 'editar':
                $this->load->model('general_model');
                $this->load->model('actividades_model');
                $data['envio'] = $this->general_model->get_envio($id);
                $data['categorias'] = $this->general_model->get_cats();
                $data['actividades'] = $this->actividades_model->get_actividades();
                $data['profesores'] = $this->actividades_model->get_profesores();
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();        
                $data['section'] = 'envios-editar';
                $this->load->view('admin',$data);
                break;

            case 'edicion':
                $titulo = $this->input->post('titulo');
                $grupo = $this->input->post('grupo');
                $data = $this->input->post('data');
                $envio = array(
                    'titulo' => $titulo, 
                    'grupo' => $grupo, 
                    'data' => json_encode($data),
                    );
                $this->load->model('general_model');
                $old_envio = $this->general_model->get_envio($id);
                $this->general_model->update_envio($id,$envio);
                if($old_envio->grupo != $grupo){                    
                    $this->general_model->clear_envio_data($id);
                    $socios = $this->general_model->get_socios_by($grupo,$data);
                    $this->load->helper('email');
                    if($socios){
                        $emails = array();
                        foreach ($socios as $socio) {
                            if (valid_email(@$socio->mail)){
                                $emails[] = $socio->mail;
                            }                        
                        }
                        $emails = array_unique($emails);
                        foreach ($emails as $email) {
                            $envio_data = array(
                                'eid' => $id, 
                                'email' => $email
                                );
                            $this->general_model->insert_envios_data($envio_data);
                        }
                        if(count($emails) <= 0){
                            echo 'no_mails';
                        }else{
                            $data['id'] = $id;
                            $data['titulo'] = $titulo;
                            $data['body'] = $old_envio->body;
                            $data['total'] = count($emails);
                            $this->load->view("envios-text",$data);
                        }
                    }else{
                        echo 'no_mails';
                    }
                }else{
                    $envios_data = $this->general_model->get_envios_data($id);                    
                    $data['id'] = $id;
                    $data['titulo'] = $titulo;
                    $data['body'] = $old_envio->body;
                    $data['total'] = count($envios_data);
                    $this->load->view("envios-text",$data);
                }
                break;
            
            default:
                $this->load->model('general_model');
                $data['envios'] = $this->general_model->get_envios();
                $data['username'] = $this->session->userdata('username');
                $data['baseurl'] = base_url();        
                $data['section'] = 'envios';
                $this->load->view('admin',$data);
                break;
        }
    }
}